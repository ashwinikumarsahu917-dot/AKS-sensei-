import 'dart:io';

import 'package:aks_aura_sensei_store/config.dart';
import 'package:aks_aura_sensei_store/models/saved_profile.dart';
import 'package:aks_aura_sensei_store/services/device_service.dart';
import 'package:aks_aura_sensei_store/state/app_state.dart';
import 'package:aks_aura_sensei_store/state/manual_draft.dart';
import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _FakeDevice extends DeviceService {
  _FakeDevice(this.reading);

  final DeviceReading reading;

  @override
  Future<DeviceReading> detect() async => reading;
}

Future<AppState> makeState({
  DeviceReading? reading,
  DateTime Function()? now,
}) async {
  SharedPreferences.setMockInitialValues({});
  final prefs = await SharedPreferences.getInstance();
  final db = DeviceDatabase.parse(File('assets/devices.json').readAsStringSync());
  return AppState(
    prefs,
    db,
    deviceService: _FakeDevice(reading ?? const DeviceReading(DetectedDevice())),
    now: now,
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('free plan limits', () {
    test('3 generations per day, then blocked; resets next day', () async {
      var clock = DateTime(2026, 10, 21, 9);
      final s = await makeState(now: () => clock);
      expect(s.remainingGenerations, kFreeDailyGenerations);
      for (var i = 0; i < kFreeDailyGenerations; i++) {
        expect(s.consumeGeneration(), isTrue);
      }
      expect(s.consumeGeneration(), isFalse);
      expect(s.remainingGenerations, 0);
      clock = DateTime(2026, 10, 22, 9);
      expect(s.remainingGenerations, kFreeDailyGenerations);
      expect(s.consumeGeneration(), isTrue);
    });

    test('only Balanced and Drag are free', () async {
      final s = await makeState();
      expect(s.canUseStyle(PlayStyle.balanced), isTrue);
      expect(s.canUseStyle(PlayStyle.drag), isTrue);
      expect(s.canUseStyle(PlayStyle.awm), isFalse);
      expect(s.canUseStyle(PlayStyle.ump), isFalse);
    });

    test('one saved profile on the free plan', () async {
      final s = await makeState();
      SavedProfile make(String n) => s.profileFromAi(n, s.baseRecommendation().profile);
      expect(await s.saveProfile(make('A')), isTrue);
      expect(s.canSaveMore, isFalse);
      expect(await s.saveProfile(make('B')), isFalse);
      expect(await s.duplicateProfile(s.profiles.first.id), isFalse);
      expect(s.profiles.length, 1);
    });

    test('premium lifts every limit (entitlement set by billing stage)', () async {
      final s = await makeState();
      s.applyEntitlement(true);
      expect(s.premium, isTrue);
      expect(s.canUseStyle(PlayStyle.awm), isTrue);
      for (var i = 0; i < 10; i++) {
        expect(s.consumeGeneration(), isTrue);
      }
      SavedProfile make(String n) => s.profileFromAi(n, s.baseRecommendation().profile);
      expect(await s.saveProfile(make('A')), isTrue);
      expect(await s.saveProfile(make('B')), isTrue);
    });
  });

  group('device flow', () {
    test('auto-detect resolves a known phone and seeds the editor', () async {
      final s = await makeState(
        reading: const DeviceReading(
          DetectedDevice(
            modelCode: 'SM-S928B',
            ramGb: 11.2,
            maxRefreshHz: 120,
            dpi: 480,
          ),
          smallestSidePx: 1440,
        ),
      );
      await s.init();
      expect(s.deviceLabel, 'Galaxy S24 Ultra');
      expect(s.device!.level, MatchLevel.exactCode);
      expect(s.dpiPlanner, isNotNull);
      expect(s.draft.profile, s.baseRecommendation().profile);
    });

    test('manual choice wins over detection and survives a restart', () async {
      final s = await makeState();
      await s.setManualDevice('poco', 'poco-f', 'poco-f6-pro');
      expect(s.deviceLabel, 'POCO F6 Pro');
      final s2 = AppState(
        await SharedPreferences.getInstance(),
        s.db,
        deviceService: _FakeDevice(const DeviceReading(DetectedDevice())),
      );
      await s2.init();
      expect(s2.deviceLabel, 'POCO F6 Pro');
    });

    test('iPhone: DPI planner is not offered', () async {
      final s = await makeState(
        reading: const DeviceReading(DetectedDevice(
          platform: DevicePlatform.ios,
          modelCode: 'iPhone17,1',
        )),
      );
      await s.init();
      expect(s.specs.dpiAdjustable, isFalse);
      expect(s.dpiPlanner, isNull);
    });

    test('edits are not overwritten when the device changes', () async {
      final s = await makeState();
      await s.setManualDevice('poco', 'poco-f', null);
      s.draft.nudge(Scope.general, 5);
      final edited = s.draft.profile;
      await s.setManualDevice('samsung', 'galaxy-s', null);
      expect(s.draft.profile, edited);
    });
  });

  group('manual draft', () {
    test('undo restores the previous value, reset the starting point', () {
      final d = ManualDraft();
      final start = SensitivityProfile(
          general: 100, redDot: 96, scope2x: 92, scope4x: 86, awm: 72, freeLook: 94);
      d.seed(start);
      d.nudge(Scope.general, 10);
      d.nudge(Scope.awm, -5);
      expect(d[Scope.general], 110);
      expect(d.canUndo, isTrue);
      d.undo();
      expect(d[Scope.awm], 72);
      expect(d[Scope.general], 110);
      d.reset();
      expect(d.profile, start);
      expect(d.canUndo, isFalse);
    });

    test('values never leave 0..200', () {
      final d = ManualDraft();
      d.setValue(Scope.redDot, 999);
      expect(d[Scope.redDot], 200);
      d.setValue(Scope.redDot, -4);
      expect(d[Scope.redDot], 0);
    });

    test('fire button stays inside the preview and size/opacity clamp', () {
      final d = ManualDraft();
      d.moveFire(5, -5);
      expect(d.fireX, 1.0);
      expect(d.fireY, 0.0);
      d.setFireSize(500);
      expect(d.fireSize, 150);
      d.setFireOpacity(0);
      expect(d.fireOpacity, 0.2);
    });
  });

  group('saved profiles', () {
    test('JSON round trip and text export carry the disclaimer', () async {
      final s = await makeState();
      final p = s.profileFromAi('Test', s.baseRecommendation().profile);
      final back = SavedProfile.fromJson(p.toJson());
      expect(back.values, p.values);
      expect(back.name, 'Test');
      expect(p.exportText(), contains('Not affiliated with'));
      expect(p.exportText(), contains('starting point'));
    });

    test('delete my data wipes profiles and sign-in', () async {
      final s = await makeState();
      await s.signInGuest();
      await s.saveProfile(s.profileFromAi('A', s.baseRecommendation().profile));
      await s.deleteAllLocalData();
      expect(s.profiles, isEmpty);
      expect(s.signedIn, isFalse);
    });
  });
}
