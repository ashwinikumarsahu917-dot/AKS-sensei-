import 'dart:io';

import 'package:aks_aura_sensei_store/main.dart';
import 'package:aks_aura_sensei_store/services/device_service.dart';
import 'package:aks_aura_sensei_store/state/app_state.dart';
import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _NoDevice extends DeviceService {
  @override
  Future<DeviceReading> detect() async => const DeviceReading(DetectedDevice());
}

void main() {
  testWidgets('splash -> login -> guest -> home shows the honesty banner',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final db = DeviceDatabase.parse(File('assets/devices.json').readAsStringSync());
    final state = AppState(prefs, db, deviceService: _NoDevice());

    await tester.pumpWidget(AksApp(state: state));
    expect(find.text('AKS AURA'), findsOneWidget);

    await tester.pump(const Duration(seconds: 2));
    await tester.pumpAndSettle();
    expect(find.text('Continue as guest'), findsOneWidget);

    await tester.tap(find.text('Continue as guest'));
    await tester.pumpAndSettle();
    expect(find.text('Device starting point'.toUpperCase()), findsOneWidget);
    expect(find.textContaining('Not affiliated').evaluate().isNotEmpty ||
        find.textContaining('not affiliated').evaluate().isNotEmpty ||
        find.textContaining('Independent app').evaluate().isNotEmpty, isTrue);
  });
}
