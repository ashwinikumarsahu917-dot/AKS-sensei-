# aks_aura_sensei_store (Flutter app)

See the repository README for build steps. Quick notes:

- `lib/state/app_state.dart` - one `ChangeNotifier` (device, plan limits, profiles, persistence via shared_preferences).
- `lib/services/billing_service.dart` - billing boundary. `StubBillingService` sells nothing and says so. Only the billing stage may call `AppState.applyEntitlement(true)`, after server-side receipt verification.
- `overlay/android/MainActivity.kt` - Kotlin device detection (MethodChannel `aks/device`), copied in by `tool/bootstrap.sh`. Needs no permissions.
- `lib/config.dart` - set `kPrivacyPolicyUrl` before a Play submission.
- Android has no API for touch sampling rate; it comes from the device DB or is estimated and labelled "(estimated)".
- Debug builds show a "Pretend to be Premium" switch on the paywall. It is compiled out of release builds (`kDebugMode`).
