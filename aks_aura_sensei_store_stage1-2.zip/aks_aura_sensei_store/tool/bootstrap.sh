#!/usr/bin/env bash
# Generates the android/ and ios/ platform folders (Flutter does that, we do
# not hand-write them) and drops in our native device-detection code.
# Run once from the app folder:   bash tool/bootstrap.sh
set -euo pipefail
cd "$(dirname "$0")/.."

# Keep our own files safe, whatever `flutter create` decides to do.
BACKUP="$(mktemp -d)"
cp -r lib test pubspec.yaml analysis_options.yaml "$BACKUP"/

flutter create . --org com.aksaura --project-name aks_aura_sensei_store --platforms android,ios

rm -rf lib test
cp -r "$BACKUP"/lib "$BACKUP"/test .
cp "$BACKUP"/pubspec.yaml "$BACKUP"/analysis_options.yaml .

KOTLIN_DIR="android/app/src/main/kotlin/com/aksaura/aks_aura_sensei_store"
mkdir -p "$KOTLIN_DIR"
cp overlay/android/MainActivity.kt "$KOTLIN_DIR/MainActivity.kt"

# Friendly launcher name.
MANIFEST="android/app/src/main/AndroidManifest.xml"
sed -i 's/android:label="[^"]*"/android:label="AKS AURA SENSEI STORE"/' "$MANIFEST"

echo "Bootstrap done. Next: flutter pub get && flutter build apk --release"
