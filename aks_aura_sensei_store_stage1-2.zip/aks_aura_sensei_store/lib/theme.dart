import 'package:flutter/material.dart';

const Color kBlack = Color(0xFF08090B);
const Color kCharcoal = Color(0xFF14161A);
const Color kPanel = Color(0xFF1C1F25);
const Color kRed = Color(0xFFFF2D4B);
const Color kBlue = Color(0xFF2BB8FF);
const Color kMuted = Color(0xFF8A90A0);

ThemeData buildTheme() {
  const scheme = ColorScheme.dark(
    primary: kRed,
    onPrimary: Colors.white,
    secondary: kBlue,
    onSecondary: Colors.black,
    surface: kCharcoal,
    onSurface: Colors.white,
    error: Color(0xFFFF6B6B),
  );
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: kBlack,
    appBarTheme: const AppBarTheme(
      backgroundColor: kBlack,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: false,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: kCharcoal,
      indicatorColor: kRed.withOpacity(0.28),
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor: kBlue,
      inactiveTrackColor: Color(0xFF2A2E36),
      thumbColor: kRed,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kPanel,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    ),
    dividerColor: const Color(0xFF2A2E36),
  );
}
