import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../widgets.dart';

class DeviceScreen extends StatefulWidget {
  const DeviceScreen({super.key});

  @override
  State<DeviceScreen> createState() => _DeviceScreenState();
}

class _DeviceScreenState extends State<DeviceScreen> {
  String? _brandId;
  String? _seriesId;
  String? _modelId;
  String _query = '';
  bool _busy = false;

  Future<void> _detect(AppState state) async {
    setState(() => _busy = true);
    await state.detectDevice();
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final db = state.db;
    final res = state.device;
    final s = state.specs;

    final brand = _brandId == null ? null : db.brand(_brandId!);
    final series = (brand == null || _seriesId == null)
        ? null
        : db.series(brand.id, _seriesId!);
    final brands = [...db.brands]..sort((a, b) => a.name.compareTo(b.name));

    return Scaffold(
      appBar: AppBar(title: const Text('Device')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          NeonCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(state.deviceLabel,
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                if (res != null) ...[
                  _row('Match', _levelText(res.level)),
                  _row('Screen', '${s.screenInches.toStringAsFixed(1)} inches'),
                  _row('Refresh rate', '${s.refreshHz} Hz'),
                  _row(
                      'Touch sampling',
                      s.touchSamplingHz == null
                          ? '~${s.effectiveTouchSamplingHz} Hz (estimated)'
                          : '${s.touchSamplingHz} Hz'),
                  _row('RAM', '${s.ramGb} GB'),
                  _row('Chipset tier', '${s.chipsetTier} of 5'),
                  _row('DPI',
                      s.dpiAdjustable ? '${s.dpi ?? 'unknown'}' : 'N/A (iPhone)'),
                  for (final n in res.notes)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(n,
                          style: const TextStyle(color: kRed, fontSize: 12)),
                    ),
                ] else
                  const Text('Nothing detected yet.',
                      style: TextStyle(color: kMuted)),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _busy ? null : () => _detect(state),
                  icon: const Icon(Icons.radar),
                  label: Text(_busy ? 'Detecting...' : 'Detect this phone'),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Android does not expose touch sampling rate, so it comes from '
                  'the device list (or is estimated and marked as such).',
                  style: TextStyle(color: kMuted, fontSize: 11),
                ),
              ],
            ),
          ),
          const SectionTitle('Search your model'),
          TextField(
            decoration: const InputDecoration(
              hintText: 'e.g. Redmi Note 13, Galaxy S24, iPhone 15',
              prefixIcon: Icon(Icons.search),
            ),
            onChanged: (v) => setState(() => _query = v),
          ),
          for (final m in db.searchModels(_query, limit: 6))
            ListTile(
              title: Text(m.name),
              subtitle: Text('${m.brandName} | ${m.seriesName}',
                  style: const TextStyle(color: kMuted)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                await state.setDeviceFromModel(m);
                if (context.mounted) showSnack(context, 'Selected ${m.name}');
              },
            ),
          const SectionTitle('Or pick: brand, series, model'),
          DropdownButtonFormField<String>(
            value: _brandId,
            hint: const Text('Brand'),
            isExpanded: true,
            items: [
              for (final b in brands)
                DropdownMenuItem(value: b.id, child: Text(b.name)),
            ],
            onChanged: (v) => setState(() {
              _brandId = v;
              _seriesId = null;
              _modelId = null;
            }),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _seriesId,
            hint: const Text('Series'),
            isExpanded: true,
            items: [
              for (final se in brand?.series ?? const <DeviceSeries>[])
                DropdownMenuItem(value: se.id, child: Text(se.name)),
            ],
            onChanged: brand == null
                ? null
                : (v) => setState(() {
                      _seriesId = v;
                      _modelId = null;
                    }),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _modelId,
            hint: const Text('Model (optional)'),
            isExpanded: true,
            items: [
              for (final m in series?.models ?? const <DeviceModel>[])
                DropdownMenuItem(value: m.id, child: Text(m.name)),
            ],
            onChanged: series == null ? null : (v) => setState(() => _modelId = v),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: (brand == null || series == null)
                ? null
                : () async {
                    await state.setManualDevice(brand.id, series.id, _modelId);
                    if (context.mounted) showSnack(context, 'Device updated');
                  },
            child: Text(_modelId == null
                ? 'Use typical values for this series'
                : 'Use this model'),
          ),
          const SizedBox(height: 18),
          const DisclaimerBanner(compact: true),
        ],
      ),
    );
  }

  static Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            SizedBox(
                width: 120,
                child: Text(k, style: const TextStyle(color: kMuted))),
            Expanded(child: Text(v)),
          ],
        ),
      );

  static String _levelText(MatchLevel l) => switch (l) {
        MatchLevel.exactCode => 'Exact (model code)',
        MatchLevel.exactName => 'Exact (name)',
        MatchLevel.manualModel => 'Chosen by you',
        MatchLevel.seriesDefaults => 'Approximate (series typical)',
        MatchLevel.genericFallback => 'Approximate (not in list)',
      };
}
