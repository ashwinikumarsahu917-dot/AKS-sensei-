import 'package:flutter/material.dart';

import '../config.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'ai_generator_screen.dart';
import 'device_screen.dart';
import 'manual_generator_screen.dart';
import 'paywall_screen.dart';
import 'profiles_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  void _go(int i) => setState(() => _index = i);

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _DashboardPage(go: _go),
      const AiGeneratorScreen(),
      const ManualGeneratorScreen(),
      ProfilesScreen(go: _go),
      const SettingsScreen(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _go,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'AI'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Manual'),
          NavigationDestination(
              icon: Icon(Icons.bookmarks_outlined), label: 'Profiles'),
          NavigationDestination(
              icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
    );
  }
}

class _DashboardPage extends StatelessWidget {
  const _DashboardPage({required this.go});

  final void Function(int) go;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final rec = state.baseRecommendation();
    final d = state.device;
    final s = state.specs;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('AKS AURA',
                  style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                      color: kRed)),
            ),
            PlanBadge(premium: state.premium),
          ],
        ),
        const SectionTitle('Your device'),
        NeonCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(state.deviceLabel,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(
                d == null
                    ? 'Tap below to detect or choose your phone.'
                    : '${s.screenInches.toStringAsFixed(1)}" | ${s.refreshHz} Hz | '
                        '${_ram(s.ramGb)} GB RAM | tier ${s.chipsetTier}'
                        '${s.dpiAdjustable ? '' : ' | DPI N/A'}',
                style: const TextStyle(color: kMuted, fontSize: 13),
              ),
              if (d != null && d.isApproximate)
                const Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Text('Approximate: pick your exact model for a closer match.',
                      style: TextStyle(color: kRed, fontSize: 12)),
                ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const DeviceScreen()),
                ),
                icon: const Icon(Icons.smartphone),
                label: const Text('Detect / change device'),
              ),
            ],
          ),
        ),
        const SectionTitle('Device starting point'),
        NeonCard(
          accent: kRed,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SensGrid(profile: rec.profile),
              const SizedBox(height: 8),
              const Text('Balanced | Gold | 3-finger',
                  style: TextStyle(color: kMuted, fontSize: 12)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: FilledButton(
                      onPressed: () => go(1),
                      child: const Text('Tune with AI'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => go(2),
                      child: const Text('Edit manually'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SectionTitle('Plan'),
        NeonCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (state.premium)
                const Text('Premium: unlimited generations, all play styles, '
                    'unlimited profiles.')
              else ...[
                Text('Free plan: ${state.remainingGenerations} of '
                    '$kFreeDailyGenerations generations left today, '
                    '$kFreeProfiles saved profile.'),
                const SizedBox(height: 10),
                FilledButton(
                  onPressed: () => openPaywall(context),
                  child: const Text('See Premium'),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),
        const DisclaimerBanner(),
      ],
    );
  }

  static String _ram(double gb) =>
      gb == gb.roundToDouble() ? gb.toInt().toString() : gb.toString();
}
