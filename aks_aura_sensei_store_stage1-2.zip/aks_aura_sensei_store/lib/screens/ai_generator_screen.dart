import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter/material.dart';

import '../config.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'device_screen.dart';
import 'paywall_screen.dart';

/// Inputs -> recommended starting point.
///
/// This build uses the offline rule-based engine. The AI backend stage swaps
/// in a server-side model (strict JSON, validated and clamped by
/// `AiSensitivityResponse`) and keeps this engine as the offline fallback.
class AiGeneratorScreen extends StatefulWidget {
  const AiGeneratorScreen({super.key});

  @override
  State<AiGeneratorScreen> createState() => _AiGeneratorScreenState();
}

class _AiGeneratorScreenState extends State<AiGeneratorScreen> {
  PlayStyle _style = PlayStyle.balanced;
  Rank _rank = Rank.gold;
  FingerSetup _fingers = FingerSetup.threeFinger;
  final Set<Problem> _problems = {};
  SensitivityRecommendation? _result;

  Future<void> _generate(AppState state) async {
    if (state.device == null) {
      showSnack(context, 'Choose your device first.');
      return;
    }
    if (!state.canUseStyle(_style)) {
      openPaywall(context);
      return;
    }
    if (!state.consumeGeneration()) {
      showSnack(context, 'Free daily limit reached. Premium removes it.');
      openPaywall(context);
      return;
    }
    final rec = state.recommend(PlayerInput(
      style: _style,
      rank: _rank,
      fingers: _fingers,
      problems: {..._problems},
    ));
    setState(() => _result = rec);
    await state.setLastAi(rec.profile);
  }

  Future<void> _save(AppState state, SensitivityRecommendation rec) async {
    if (!state.canSaveMore) {
      showSnack(context, 'Free plan holds $kFreeProfiles profile. See Premium.');
      openPaywall(context);
      return;
    }
    final name = await promptText(
      context,
      title: 'Profile name',
      initial: '${_style.label} - ${state.deviceLabel}',
    );
    if (name == null || name.isEmpty) return;
    final ok = await state.saveProfile(state.profileFromAi(name, rec.profile));
    if (mounted && ok) showSnack(context, 'Saved "$name"');
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final rec = _result;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('AI sensei',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const Text('Offline rule-based engine in this build.',
            style: TextStyle(color: kMuted, fontSize: 12)),
        if (state.device == null) ...[
          const SizedBox(height: 12),
          NeonCard(
            accent: kRed,
            child: Row(
              children: [
                const Expanded(child: Text('Choose your device first.')),
                FilledButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                        builder: (_) => const DeviceScreen()),
                  ),
                  child: const Text('Choose'),
                ),
              ],
            ),
          ),
        ],
        const SectionTitle('Play style'),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            for (final s in PlayStyle.values)
              ChoiceChip(
                label: Text(s.label),
                avatar: state.canUseStyle(s)
                    ? null
                    : const Icon(Icons.lock_outline, size: 16),
                selected: _style == s,
                onSelected: (_) {
                  if (!state.canUseStyle(s)) {
                    openPaywall(context);
                    return;
                  }
                  setState(() => _style = s);
                },
              ),
          ],
        ),
        const SectionTitle('Rank'),
        DropdownButtonFormField<Rank>(
          value: _rank,
          items: [
            for (final r in Rank.values)
              DropdownMenuItem(value: r, child: Text(r.label)),
          ],
          onChanged: (v) => setState(() => _rank = v ?? _rank),
        ),
        const SectionTitle('Finger setup'),
        SegmentedButton<FingerSetup>(
          showSelectedIcon: false,
          segments: [
            for (final f in FingerSetup.values)
              ButtonSegment(value: f, label: Text(f.label)),
          ],
          selected: {_fingers},
          onSelectionChanged: (v) => setState(() => _fingers = v.first),
        ),
        const SectionTitle('Problems you notice'),
        Wrap(
          spacing: 8,
          children: [
            for (final p in Problem.values)
              FilterChip(
                label: Text(p.label),
                selected: _problems.contains(p),
                onSelected: (on) => setState(() {
                  if (on) {
                    _problems.add(p);
                  } else {
                    _problems.remove(p);
                  }
                }),
              ),
          ],
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: () => _generate(state),
          icon: const Icon(Icons.auto_awesome),
          label: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(state.premium
                ? 'Generate'
                : 'Generate (${state.remainingGenerations} left today)'),
          ),
        ),
        if (rec != null) ...[
          const SectionTitle('Recommended starting point'),
          NeonCard(
            accent: kRed,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SensGrid(profile: rec.profile),
                const SizedBox(height: 12),
                for (final s in Scope.values)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Text(rec.explain(s),
                        style: const TextStyle(color: kMuted, fontSize: 12)),
                  ),
                for (final w in rec.warnings)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(w.text,
                        style: const TextStyle(color: kRed, fontSize: 12)),
                  ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton(
                        onPressed: () => _save(state, rec),
                        child: const Text('Save profile'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          state.draft
                              .seed(rec.profile, dpiValue: state.specs.dpi, force: true);
                          showSnack(context,
                              'Loaded into the Manual tab - open it to fine-tune.');
                        },
                        child: const Text('Edit manually'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 16),
        const DisclaimerBanner(),
      ],
    );
  }
}
