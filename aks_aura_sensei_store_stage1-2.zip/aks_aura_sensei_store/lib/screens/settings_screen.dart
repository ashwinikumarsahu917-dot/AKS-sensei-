import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'login_screen.dart';
import 'paywall_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Settings',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SectionTitle('Plan'),
        NeonCard(
          child: Row(
            children: [
              PlanBadge(premium: state.premium),
              const SizedBox(width: 12),
              Expanded(
                child: Text(state.premium ? 'Premium active' : 'Free plan'),
              ),
              if (!state.premium)
                TextButton(
                  onPressed: () => openPaywall(context),
                  child: const Text('Upgrade'),
                ),
            ],
          ),
        ),
        const SectionTitle('Privacy & data'),
        NeonCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'This build stores your profiles and choices only on this phone. '
                'It needs no permissions, collects no contacts, location or '
                'advertising ID, and shows no ads.',
                style: TextStyle(color: kMuted, fontSize: 13, height: 1.35),
              ),
              TextButton(
                onPressed: () async {
                  try {
                    await launchUrl(Uri.parse(kPrivacyPolicyUrl),
                        mode: LaunchMode.externalApplication);
                  } catch (_) {
                    if (context.mounted) showSnack(context, 'Could not open the link.');
                  }
                },
                child: const Text('Privacy policy'),
              ),
            ],
          ),
        ),
        const SectionTitle('Account'),
        NeonCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Guest mode', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              const Text(
                'Deleting removes every profile and setting stored on this phone. '
                'This cannot be undone.',
                style: TextStyle(color: kMuted, fontSize: 12),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => _confirmDelete(context, state),
                icon: const Icon(Icons.delete_outline, color: kRed),
                label: const Text('Delete my data'),
              ),
            ],
          ),
        ),
        const SectionTitle('About'),
        const NeonCard(
          child: Text(
            '$kAppName 0.1.0\n\n$kDisclaimerLong\n\nThe app cannot read or change Free '
            'Fire settings, and it contains no cheats, injection or anti-cheat '
            'bypass.',
            style: TextStyle(color: kMuted, fontSize: 12, height: 1.4),
          ),
        ),
      ],
    );
  }

  Future<void> _confirmDelete(BuildContext context, AppState state) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kPanel,
        title: const Text('Delete all data?'),
        content: const Text(
            'All saved profiles and settings on this phone will be erased.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    await state.deleteAllLocalData();
    if (!context.mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }
}
