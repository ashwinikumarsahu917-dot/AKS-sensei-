import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../share_card.dart';
import '../state/app_state.dart';
import '../state/manual_draft.dart';
import '../theme.dart';
import '../widgets.dart';
import 'paywall_screen.dart';

class ManualGeneratorScreen extends StatelessWidget {
  const ManualGeneratorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final draft = state.draft;
    return ListenableBuilder(
      listenable: draft,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('Manual sensei',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              ),
              IconButton(
                tooltip: 'Undo',
                onPressed: draft.canUndo ? draft.undo : null,
                icon: const Icon(Icons.undo),
              ),
              IconButton(
                tooltip: 'Reset to starting point',
                onPressed: draft.reset,
                icon: const Icon(Icons.restart_alt),
              ),
            ],
          ),
          Text('Starting point for ${state.deviceLabel}',
              style: const TextStyle(color: kMuted, fontSize: 12)),
          const SizedBox(height: 10),
          for (final s in Scope.values) ...[
            _ScopeEditor(scope: s, draft: draft),
            const SizedBox(height: 10),
          ],
          const SectionTitle('DPI'),
          _DpiCard(state: state, draft: draft),
          const SectionTitle('Fire button'),
          _FireCard(draft: draft),
          const SectionTitle('Actions'),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              FilledButton.icon(
                onPressed: () => _save(context, state),
                icon: const Icon(Icons.bookmark_add_outlined),
                label: const Text('Save'),
              ),
              OutlinedButton.icon(
                onPressed: () => _compare(context, state),
                icon: const Icon(Icons.compare_arrows),
                label: const Text('Compare with AI'),
              ),
              OutlinedButton.icon(
                onPressed: () async {
                  final p = state.profileFromDraft('Manual - ${state.deviceLabel}');
                  await Clipboard.setData(ClipboardData(text: p.exportText()));
                  if (context.mounted) showSnack(context, 'Copied to clipboard');
                },
                icon: const Icon(Icons.copy),
                label: const Text('Export text'),
              ),
              OutlinedButton.icon(
                onPressed: () => showShareCard(
                  context,
                  state.profileFromDraft('Manual - ${state.deviceLabel}'),
                ),
                icon: const Icon(Icons.image_outlined),
                label: const Text('Share card'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const DisclaimerBanner(),
        ],
      ),
    );
  }

  Future<void> _save(BuildContext context, AppState state) async {
    if (!state.canSaveMore) {
      showSnack(context, 'Free plan is full. Premium allows unlimited profiles.');
      openPaywall(context);
      return;
    }
    final name = await promptText(
      context,
      title: 'Profile name',
      initial: 'Manual - ${state.deviceLabel}',
    );
    if (name == null || name.isEmpty) return;
    final ok = await state.saveProfile(state.profileFromDraft(name));
    if (context.mounted && ok) showSnack(context, 'Saved "$name"');
  }

  void _compare(BuildContext context, AppState state) {
    final ai = state.lastAi;
    if (ai == null) {
      showSnack(context, 'Generate an AI result first, then compare.');
      return;
    }
    showCompareDialog(
      context,
      aLabel: 'Manual',
      a: state.draft.profile,
      bLabel: 'AI',
      b: ai,
    );
  }
}

class _ScopeEditor extends StatelessWidget {
  const _ScopeEditor({required this.scope, required this.draft});

  final Scope scope;
  final ManualDraft draft;

  @override
  Widget build(BuildContext context) {
    final value = draft[scope];
    return NeonCard(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(scope.label,
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w700)),
              ),
              SizedBox(
                width: 76,
                child: TextFormField(
                  key: ValueKey('${scope.name}-$value-${draft.revision}'),
                  initialValue: '$value',
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(isDense: true),
                  onFieldSubmitted: (t) {
                    final v = int.tryParse(t);
                    if (v == null) return;
                    draft.beginEdit();
                    draft.setValue(scope, v);
                  },
                ),
              ),
            ],
          ),
          Row(
            children: [
              IconButton(
                tooltip: 'Minus 1',
                onPressed: value > kSensitivityMin
                    ? () => draft.nudge(scope, -1)
                    : null,
                icon: const Icon(Icons.remove_circle_outline),
              ),
              Expanded(
                child: Slider(
                  value: value.toDouble(),
                  min: kSensitivityMin.toDouble(),
                  max: kSensitivityMax.toDouble(),
                  divisions: kSensitivityMax - kSensitivityMin,
                  onChangeStart: (_) => draft.beginEdit(),
                  onChanged: (v) => draft.setValue(scope, v.round()),
                ),
              ),
              IconButton(
                tooltip: 'Plus 1',
                onPressed: value < kSensitivityMax
                    ? () => draft.nudge(scope, 1)
                    : null,
                icon: const Icon(Icons.add_circle_outline),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DpiCard extends StatelessWidget {
  const _DpiCard({required this.state, required this.draft});

  final AppState state;
  final ManualDraft draft;

  @override
  Widget build(BuildContext context) {
    final specs = state.specs;
    if (!specs.dpiAdjustable) {
      return const NeonCard(
        child: Text(
          'DPI: N/A. iPhone display density is fixed, so there is nothing to '
          'change. Tune with the sensitivity values and your screen size instead.',
          style: TextStyle(color: kMuted),
        ),
      );
    }
    final planner = state.dpiPlanner;
    final current = specs.dpi;
    final target = draft.dpi ?? current;
    return NeonCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Current DPI: ${current ?? 'unknown'}'),
          if (planner == null)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text(
                'This phone did not report its screen size, so no DPI range '
                'can be suggested. Keep the DPI you already use.',
                style: TextStyle(color: kMuted, fontSize: 12),
              ),
            )
          else ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (final p in planner.presets)
                  ChoiceChip(
                    label: Text(p == planner.nativeDpi ? '$p (current)' : '$p'),
                    selected: target == p,
                    onSelected: (_) => draft.setDpi(p),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            if (target != null && target != planner.nativeDpi) ...[
              Text('Target ${planner.clampDpi(target)} dpi = Smallest width '
                  '${planner.smallestWidthDp(planner.clampDpi(target))} dp',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              SelectableText(
                'ADB: ${planner.adbCommand(planner.clampDpi(target))}\n'
                'Undo: ${DpiPlanner.adbReset}',
                style: const TextStyle(color: kBlue, fontSize: 12),
              ),
              const SizedBox(height: 6),
            ],
          ],
          const Text(
            'Android does not let apps change DPI silently. To apply a value, '
            'open Settings > Developer options > Smallest width and enter the '
            'dp shown above, or use the ADB command from a computer. Changing '
            'DPI affects every app; if the screen becomes hard to use, reset it.',
            style: TextStyle(color: kMuted, fontSize: 12, height: 1.35),
          ),
        ],
      ),
    );
  }
}

class _FireCard extends StatelessWidget {
  const _FireCard({required this.draft});

  final ManualDraft draft;

  @override
  Widget build(BuildContext context) {
    return NeonCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Drag the red button to plan where it sits.',
              style: TextStyle(color: kMuted, fontSize: 12)),
          const SizedBox(height: 8),
          AspectRatio(
            aspectRatio: 20 / 9,
            child: LayoutBuilder(builder: (context, box) {
              final size = 44 * draft.fireSize / 100;
              final freeW = (box.maxWidth - size).clamp(1.0, double.infinity);
              final freeH = (box.maxHeight - size).clamp(1.0, double.infinity);
              return Container(
                decoration: BoxDecoration(
                  color: kBlack,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kBlue.withOpacity(0.4)),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: draft.fireX * freeW,
                      top: draft.fireY * freeH,
                      child: GestureDetector(
                        onPanUpdate: (d) =>
                            draft.moveFire(d.delta.dx / freeW, d.delta.dy / freeH),
                        child: Container(
                          width: size,
                          height: size,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: kRed.withOpacity(draft.fireOpacity),
                            boxShadow: [
                              BoxShadow(
                                  color: kRed.withOpacity(0.5), blurRadius: 10),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
          ),
          const SizedBox(height: 8),
          Text('Size: ${draft.fireSize.round()}%'),
          Slider(
            value: draft.fireSize,
            min: 50,
            max: 150,
            divisions: 100,
            onChangeStart: (_) => draft.beginEdit(),
            onChanged: draft.setFireSize,
          ),
          Text('Opacity: ${(draft.fireOpacity * 100).round()}%'),
          Slider(
            value: draft.fireOpacity,
            min: 0.2,
            max: 1.0,
            onChangeStart: (_) => draft.beginEdit(),
            onChanged: draft.setFireOpacity,
          ),
          const Text(
            'This preview is a planning aid. Set the real button in Free Fire > '
            'Settings > Custom HUD.',
            style: TextStyle(color: kMuted, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
