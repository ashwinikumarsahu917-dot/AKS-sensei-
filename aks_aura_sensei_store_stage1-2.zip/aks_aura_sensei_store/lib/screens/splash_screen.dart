import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme.dart';
import 'home_screen.dart';
import 'login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    _boot();
  }

  Future<void> _boot() async {
    final state = AppScope.of(context);
    await Future.wait<void>([
      state.init(),
      Future<void>.delayed(const Duration(milliseconds: 900)),
    ]);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
      builder: (_) =>
          state.signedIn ? const HomeScreen() : const LoginScreen(),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'AKS AURA',
              style: TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.w900,
                letterSpacing: 4,
                color: kRed,
                shadows: [Shadow(color: kRed.withOpacity(0.8), blurRadius: 24)],
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'SENSEI STORE',
              style: TextStyle(
                fontSize: 18,
                letterSpacing: 8,
                color: kBlue,
                shadows: [Shadow(color: kBlue.withOpacity(0.8), blurRadius: 16)],
              ),
            ),
            const SizedBox(height: 28),
            const SizedBox(
              width: 26,
              height: 26,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
          ],
        ),
      ),
    );
  }
}
