import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'home_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 40),
            Text(
              'AKS AURA',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.w900,
                letterSpacing: 4,
                color: kRed,
                shadows: [Shadow(color: kRed.withOpacity(0.7), blurRadius: 22)],
              ),
            ),
            const Text(
              'SENSEI STORE',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, letterSpacing: 7, color: kBlue),
            ),
            const SizedBox(height: 36),
            const Text(
              'Device-optimised Free Fire sensitivity starting points.',
              textAlign: TextAlign.center,
              style: TextStyle(color: kMuted),
            ),
            const SizedBox(height: 32),
            FilledButton(
              onPressed: () async {
                await state.signInGuest();
                if (!context.mounted) return;
                Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
                  builder: (_) => const HomeScreen(),
                ));
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('Continue as guest'),
              ),
            ),
            const SizedBox(height: 12),
            // Real sign-in needs Firebase project files that only the app
            // owner can create (google-services.json / GoogleService-Info.plist).
            const OutlinedButton(
              onPressed: null,
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('Sign in with Google'),
              ),
            ),
            const SizedBox(height: 12),
            const OutlinedButton(
              onPressed: null,
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('Sign in with Apple'),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Google and Apple sign-in switch on once your Firebase project is '
              'connected (see README). Guest mode keeps everything on this phone.',
              textAlign: TextAlign.center,
              style: TextStyle(color: kMuted, fontSize: 12),
            ),
            const SizedBox(height: 28),
            const DisclaimerBanner(),
          ],
        ),
      ),
    );
  }
}
