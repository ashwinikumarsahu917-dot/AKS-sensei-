import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/saved_profile.dart';
import '../share_card.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'paywall_screen.dart';

class ProfilesScreen extends StatelessWidget {
  const ProfilesScreen({super.key, required this.go});

  /// Switches the bottom-navigation tab (2 = Manual).
  final void Function(int) go;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final list = state.profiles;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Saved profiles',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        if (!state.premium)
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Text('Free plan: 1 saved profile. Premium: unlimited.',
                style: TextStyle(color: kMuted, fontSize: 12)),
          ),
        const SizedBox(height: 12),
        if (list.isEmpty)
          const NeonCard(
            child: Text(
              'Nothing saved yet. Generate with AI or edit manually, then tap Save.',
              style: TextStyle(color: kMuted),
            ),
          ),
        for (final p in list) ...[
          _ProfileCard(profile: p, go: go),
          const SizedBox(height: 10),
        ],
        const SizedBox(height: 8),
        const DisclaimerBanner(compact: true),
      ],
    );
  }
}

class _ProfileCard extends StatelessWidget {
  const _ProfileCard({required this.profile, required this.go});

  final SavedProfile profile;
  final void Function(int) go;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final p = profile;
    return NeonCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(p.name,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
              ),
              PopupMenuButton<String>(
                onSelected: (v) => _onMenu(context, state, v),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('Open in editor')),
                  PopupMenuItem(value: 'rename', child: Text('Rename')),
                  PopupMenuItem(value: 'dup', child: Text('Duplicate')),
                  PopupMenuItem(value: 'compare', child: Text('Compare with AI')),
                  PopupMenuItem(value: 'copy', child: Text('Copy as text')),
                  PopupMenuItem(value: 'share', child: Text('Share image')),
                  PopupMenuItem(value: 'delete', child: Text('Delete')),
                ],
              ),
            ],
          ),
          Text(
            '${p.deviceLabel} | ${p.source == ProfileSource.ai ? 'AI' : 'Manual'}',
            style: const TextStyle(color: kMuted, fontSize: 12),
          ),
          const SizedBox(height: 10),
          SensGrid(profile: p.values),
        ],
      ),
    );
  }

  Future<void> _onMenu(BuildContext context, AppState state, String v) async {
    switch (v) {
      case 'edit':
        state.draft.loadProfile(profile);
        go(2);
      case 'rename':
        final name = await promptText(context,
            title: 'Rename profile', initial: profile.name);
        if (name != null && name.isNotEmpty) {
          await state.renameProfile(profile.id, name);
        }
      case 'dup':
        final ok = await state.duplicateProfile(profile.id);
        if (!context.mounted) return;
        if (!ok) {
          showSnack(context, 'Free plan is full. Premium allows unlimited profiles.');
          openPaywall(context);
        }
      case 'compare':
        final ai = state.lastAi;
        if (ai == null) {
          showSnack(context, 'Generate an AI result first, then compare.');
        } else {
          await showCompareDialog(
            context,
            aLabel: 'Saved',
            a: profile.values,
            bLabel: 'AI',
            b: ai,
          );
        }
      case 'copy':
        await Clipboard.setData(ClipboardData(text: profile.exportText()));
        if (context.mounted) showSnack(context, 'Copied to clipboard');
      case 'share':
        await showShareCard(context, profile);
      case 'delete':
        await state.deleteProfile(profile.id);
    }
  }
}
