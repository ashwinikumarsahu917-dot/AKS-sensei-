import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../services/billing_service.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets.dart';

void openPaywall(BuildContext context) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => const PaywallScreen()),
  );
}

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key});

  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen> {
  bool _busy = false;

  Future<void> _run(Future<BillingOutcome> Function() action) async {
    setState(() => _busy = true);
    final outcome = await action();
    if (!mounted) return;
    setState(() => _busy = false);
    showSnack(
      context,
      switch (outcome) {
        BillingOutcome.success => 'Premium is active. Thank you!',
        BillingOutcome.cancelled => 'Purchase cancelled. You were not charged.',
        BillingOutcome.notConfigured =>
          'Subscriptions are not switched on in this build yet, so nothing was charged.',
        BillingOutcome.error => 'Something went wrong. You were not charged.',
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Premium')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const NeonCard(
            accent: kRed,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('AKS AURA Premium',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                SizedBox(height: 10),
                _Perk('Unlimited AI generations'),
                _Perk('All play-style presets'),
                _Perk('Unlimited saved profiles'),
                _Perk('Cloud sync (arrives with accounts)'),
              ],
            ),
          ),
          const SectionTitle('Free plan'),
          const NeonCard(
            child: Text(
              '$kFreeDailyGenerations generations per day, $kFreeProfiles saved '
              'profile, Balanced and Drag styles.',
              style: TextStyle(color: kMuted),
            ),
          ),
          const SectionTitle('Choose a plan'),
          NeonCard(
            child: Column(
              children: [
                const Text(
                  'The exact price and billing period are shown by Google Play '
                  'before you confirm. Nothing is charged until you confirm there.',
                  style: TextStyle(color: kMuted, fontSize: 13),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton(
                        onPressed: _busy
                            ? null
                            : () => _run(() => state.billing.purchase(BillingPlan.monthly)),
                        child: const Text('Monthly'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton(
                        onPressed: _busy
                            ? null
                            : () => _run(() => state.billing.purchase(BillingPlan.yearly)),
                        child: const Text('Yearly'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: _busy ? null : () => _run(state.billing.restore),
                  child: const Text('Restore purchases'),
                ),
              ],
            ),
          ),
          const SectionTitle('Terms'),
          const Text(
            'Subscriptions renew automatically at the end of each period until '
            'you cancel. Cancel any time in Google Play > Payments & '
            'subscriptions > Subscriptions; you keep Premium until the period '
            'you paid for ends. If a renewal payment fails, Google Play may give '
            'a short grace period before Premium stops. Results are '
            'recommended starting points, not guarantees.',
            style: TextStyle(color: kMuted, fontSize: 12, height: 1.4),
          ),
          TextButton(
            onPressed: () async {
              try {
                await launchUrl(Uri.parse(kManageSubscriptionUrl),
                    mode: LaunchMode.externalApplication);
              } catch (_) {
                if (context.mounted) showSnack(context, 'Could not open Google Play.');
              }
            },
            child: const Text('Manage or cancel subscription'),
          ),
          if (kDebugMode) ...[
            const SectionTitle('Debug build only'),
            SwitchListTile(
              title: const Text('Pretend to be Premium'),
              subtitle: const Text('For testing the UI. Not available in release builds.'),
              value: state.debugPremium,
              onChanged: state.setDebugPremium,
            ),
          ],
        ],
      ),
    );
  }
}

class _Perk extends StatelessWidget {
  const _Perk(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          const Icon(Icons.check_circle, size: 18, color: kBlue),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
