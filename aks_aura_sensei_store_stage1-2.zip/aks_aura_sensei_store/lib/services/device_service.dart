import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// What the phone told us, plus the smaller screen side (needed by the DPI
/// planner; the core `DetectedDevice` does not carry it).
class DeviceReading {
  const DeviceReading(this.device, {this.smallestSidePx});

  final DetectedDevice device;
  final int? smallestSidePx;
}

/// Android: native Kotlin module (channel "aks/device").
/// iOS: model identifier via device_info_plus; everything else comes from the
/// device database. No permissions are needed for either.
class DeviceService {
  static const MethodChannel _channel = MethodChannel('aks/device');

  Future<DeviceReading> detect() async {
    try {
      switch (defaultTargetPlatform) {
        case TargetPlatform.android:
          final m = await _channel
              .invokeMapMethod<String, Object?>('getDeviceInfo');
          if (m == null) return const DeviceReading(DetectedDevice());
          final w = (m['widthPx'] as num?)?.toInt();
          final h = (m['heightPx'] as num?)?.toInt();
          return DeviceReading(
            DetectedDevice(
              manufacturer: m['manufacturer'] as String?,
              modelCode: m['model'] as String?,
              screenInches: (m['screenInches'] as num?)?.toDouble(),
              maxRefreshHz: (m['maxRefreshHz'] as num?)?.round(),
              ramGb: (m['ramGb'] as num?)?.toDouble(),
              dpi: (m['dpi'] as num?)?.toInt(),
            ),
            smallestSidePx: (w != null && h != null) ? (w < h ? w : h) : null,
          );
        case TargetPlatform.iOS:
          final info = await DeviceInfoPlugin().iosInfo;
          return DeviceReading(DetectedDevice(
            platform: DevicePlatform.ios,
            manufacturer: 'Apple',
            modelCode: info.utsname.machine,
          ));
        default:
          return const DeviceReading(DetectedDevice());
      }
    } on PlatformException {
      return const DeviceReading(DetectedDevice());
    } on MissingPluginException {
      return const DeviceReading(DetectedDevice());
    }
  }
}
