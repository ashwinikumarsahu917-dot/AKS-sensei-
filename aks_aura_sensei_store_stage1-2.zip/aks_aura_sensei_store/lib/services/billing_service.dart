enum BillingPlan { monthly, yearly }

enum BillingOutcome { success, cancelled, notConfigured, error }

/// Store billing boundary. The real implementation (Google Play Billing on
/// Android, StoreKit on iOS, with server-side receipt verification) arrives in
/// the billing stage. Until then this build cannot sell anything, and the UI
/// says so instead of pretending.
abstract class BillingService {
  Future<BillingOutcome> purchase(BillingPlan plan);
  Future<BillingOutcome> restore();
}

class StubBillingService implements BillingService {
  const StubBillingService();

  @override
  Future<BillingOutcome> purchase(BillingPlan plan) async =>
      BillingOutcome.notConfigured;

  @override
  Future<BillingOutcome> restore() async => BillingOutcome.notConfigured;
}
