import 'dart:io';
import 'dart:ui' as ui;

import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'models/saved_profile.dart';
import 'theme.dart';
import 'widgets.dart';

Future<void> showShareCard(BuildContext context, SavedProfile profile) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: kCharcoal,
    builder: (_) => _ShareCardSheet(profile: profile),
  );
}

class _ShareCardSheet extends StatefulWidget {
  const _ShareCardSheet({required this.profile});

  final SavedProfile profile;

  @override
  State<_ShareCardSheet> createState() => _ShareCardSheetState();
}

class _ShareCardSheetState extends State<_ShareCardSheet> {
  final GlobalKey _boundaryKey = GlobalKey();
  bool _busy = false;

  Future<void> _share() async {
    setState(() => _busy = true);
    try {
      final boundary = _boundaryKey.currentContext!.findRenderObject()!
          as RenderRepaintBoundary;
      final image = await boundary.toImage(pixelRatio: 3);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw StateError('Could not render the card');
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/aks_sensei_${widget.profile.id}.png');
      await file.writeAsBytes(data.buffer.asUint8List());
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Recommended Free Fire sensitivity starting point: '
            '${widget.profile.name}',
      );
    } catch (e) {
      if (mounted) showSnack(context, 'Could not share the card: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.profile;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RepaintBoundary(
              key: _boundaryKey,
              child: Container(
                width: 340,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF0B0C10), Color(0xFF1B0A12)],
                  ),
                  border: Border.all(color: kRed.withOpacity(0.7), width: 1.5),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('AKS AURA SENSEI',
                        style: TextStyle(
                            color: kRed,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                            fontSize: 13)),
                    const SizedBox(height: 6),
                    Text(p.name,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w800)),
                    Text(p.deviceLabel,
                        style: const TextStyle(color: kMuted, fontSize: 12)),
                    const SizedBox(height: 14),
                    for (final s in Scope.values)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(
                          children: [
                            Expanded(
                                child: Text(s.label,
                                    style: const TextStyle(fontSize: 14))),
                            Text('${p.values[s]}',
                                style: const TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800,
                                    color: kBlue)),
                          ],
                        ),
                      ),
                    const Divider(height: 22),
                    Text(
                      'DPI ${p.dpi ?? 'N/A'}  |  Fire button ${p.fireSizePercent.round()}%',
                      style: const TextStyle(color: kMuted, fontSize: 12),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Recommended starting point, not a guarantee. '
                      'Independent app, not affiliated with Garena.',
                      style: TextStyle(color: kMuted, fontSize: 10, height: 1.3),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _busy ? null : _share,
                icon: const Icon(Icons.ios_share),
                label: Text(_busy ? 'Preparing...' : 'Share image'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
