/// App-wide constants. Replace the TODO values before a Play Store release.
library;

const String kAppName = 'AKS AURA SENSEI STORE';

/// TODO: host the privacy policy (see docs) and put its public URL here.
/// Google Play requires a working URL in the store listing.
const String kPrivacyPolicyUrl = 'https://example.com/aks-aura/privacy';

/// Google Play's own page where users manage / cancel subscriptions.
const String kManageSubscriptionUrl =
    'https://play.google.com/store/account/subscriptions';

const String kDisclaimerLong =
    'Values are a recommended starting point, not a guarantee of better aim. '
    'Fine-tune them in training. This app cannot change Free Fire for you: '
    'enter the numbers yourself in Free Fire > Settings > Sensitivity. '
    'Independent app, not affiliated with or endorsed by Garena.';

const String kDisclaimerShort =
    'Recommended starting point - not a guarantee. Not affiliated with Garena.';

/// Free-plan limits. NOTE: these are enforced on the device for now. The AI
/// backend stage re-checks the daily limit on the server, because a local
/// counter can be reset by clearing app data.
const int kFreeProfiles = 1;
const int kFreeDailyGenerations = 3;
