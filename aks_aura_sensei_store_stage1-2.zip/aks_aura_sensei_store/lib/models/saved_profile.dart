import 'package:aks_sensei_core/aks_sensei_core.dart';

enum ProfileSource { ai, manual }

/// A profile the user saved: the six values plus DPI / fire-button notes.
/// Everything is a *recommendation* the user types into Free Fire by hand.
class SavedProfile {
  const SavedProfile({
    required this.id,
    required this.name,
    required this.values,
    required this.deviceLabel,
    required this.source,
    required this.createdAt,
    this.dpi,
    this.fireSizePercent = 100,
    this.fireX = 0.82,
    this.fireY = 0.62,
    this.fireOpacity = 0.85,
  });

  final String id;
  final String name;
  final SensitivityProfile values;
  final String deviceLabel;
  final ProfileSource source;
  final DateTime createdAt;
  final int? dpi;
  final double fireSizePercent;
  final double fireX;
  final double fireY;
  final double fireOpacity;

  SavedProfile copyWith({String? id, String? name, DateTime? createdAt}) {
    return SavedProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      values: values,
      deviceLabel: deviceLabel,
      source: source,
      createdAt: createdAt ?? this.createdAt,
      dpi: dpi,
      fireSizePercent: fireSizePercent,
      fireX: fireX,
      fireY: fireY,
      fireOpacity: fireOpacity,
    );
  }

  Map<String, Object?> toJson() => {
        'id': id,
        'name': name,
        'values': values.toJson(),
        'deviceLabel': deviceLabel,
        'source': source.name,
        'createdAt': createdAt.toIso8601String(),
        'dpi': dpi,
        'fireSize': fireSizePercent,
        'fireX': fireX,
        'fireY': fireY,
        'fireOpacity': fireOpacity,
      };

  factory SavedProfile.fromJson(Map<String, Object?> j) {
    return SavedProfile(
      id: j['id'] as String,
      name: j['name'] as String,
      values: SensitivityProfile.fromJson(
          (j['values'] as Map).cast<String, Object?>()),
      deviceLabel: (j['deviceLabel'] as String?) ?? 'Unknown device',
      source: ProfileSource.values.firstWhere(
        (s) => s.name == j['source'],
        orElse: () => ProfileSource.manual,
      ),
      createdAt:
          DateTime.tryParse((j['createdAt'] as String?) ?? '') ?? DateTime.now(),
      dpi: (j['dpi'] as num?)?.toInt(),
      fireSizePercent: (j['fireSize'] as num?)?.toDouble() ?? 100,
      fireX: (j['fireX'] as num?)?.toDouble() ?? 0.82,
      fireY: (j['fireY'] as num?)?.toDouble() ?? 0.62,
      fireOpacity: (j['fireOpacity'] as num?)?.toDouble() ?? 0.85,
    );
  }

  /// Plain-text export (clipboard / share sheet).
  String exportText() {
    final b = StringBuffer()
      ..writeln('AKS AURA SENSEI STORE - recommended starting point')
      ..writeln('Profile: $name')
      ..writeln('Device: $deviceLabel');
    for (final s in Scope.values) {
      b.writeln('${s.label}: ${values[s]}');
    }
    b.writeln(dpi == null ? 'DPI: N/A' : 'DPI: $dpi');
    b.writeln('Fire button: ${fireSizePercent.round()}% size, '
        '${(fireOpacity * 100).round()}% opacity');
    b.write('Enter these values manually in Free Fire. Not affiliated with '
        'Garena. Results are a starting point, not a guarantee.');
    return b.toString();
  }
}
