import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter/foundation.dart';

import '../models/saved_profile.dart';

typedef _Snap = ({
  List<int> v,
  int? dpi,
  double size,
  double x,
  double y,
  double opacity,
});

/// Editable state behind the manual generator: six values, DPI target and
/// fire-button layout, with undo and reset-to-baseline.
class ManualDraft extends ChangeNotifier {
  static const double defaultFireSize = 100;
  static const double defaultFireX = 0.82;
  static const double defaultFireY = 0.62;
  static const double defaultFireOpacity = 0.85;

  List<int> _values = List<int>.filled(6, 100);
  List<int> _baseline = List<int>.filled(6, 100);
  int? dpi;
  int? _baselineDpi;
  double fireSize = defaultFireSize;
  double fireX = defaultFireX;
  double fireY = defaultFireY;
  double fireOpacity = defaultFireOpacity;

  /// True once the user changed something, so a device change does not wipe
  /// their edits.
  bool dirty = false;

  /// Bumped on every edit so text fields can rebuild with the clamped value.
  int revision = 0;

  final List<_Snap> _undo = [];

  bool get canUndo => _undo.isNotEmpty;

  int operator [](Scope s) => _values[s.index];

  SensitivityProfile get profile => SensitivityProfile(
        general: _values[0],
        redDot: _values[1],
        scope2x: _values[2],
        scope4x: _values[3],
        awm: _values[4],
        freeLook: _values[5],
      );

  _Snap _snap() => (
        v: List<int>.of(_values),
        dpi: dpi,
        size: fireSize,
        x: fireX,
        y: fireY,
        opacity: fireOpacity,
      );

  void _restore(_Snap s) {
    _values = List<int>.of(s.v);
    dpi = s.dpi;
    fireSize = s.size;
    fireX = s.x;
    fireY = s.y;
    fireOpacity = s.opacity;
  }

  /// Sets a new starting point. Ignored when the user already edited, unless
  /// [force] is true.
  void seed(SensitivityProfile p, {int? dpiValue, bool force = false}) {
    if (dirty && !force) return;
    _values = [p.general, p.redDot, p.scope2x, p.scope4x, p.awm, p.freeLook];
    _baseline = List<int>.of(_values);
    dpi = dpiValue;
    _baselineDpi = dpiValue;
    fireSize = defaultFireSize;
    fireX = defaultFireX;
    fireY = defaultFireY;
    fireOpacity = defaultFireOpacity;
    _undo.clear();
    dirty = false;
    revision++;
    notifyListeners();
  }

  /// Load a saved profile into the editor (counts as an edit).
  void loadProfile(SavedProfile p) {
    beginEdit();
    _values = [
      p.values.general,
      p.values.redDot,
      p.values.scope2x,
      p.values.scope4x,
      p.values.awm,
      p.values.freeLook,
    ];
    dpi = p.dpi;
    fireSize = p.fireSizePercent;
    fireX = p.fireX;
    fireY = p.fireY;
    fireOpacity = p.fireOpacity;
    revision++;
    notifyListeners();
  }

  /// Call once before a gesture / change so it can be undone as one step.
  void beginEdit() {
    _undo.add(_snap());
    if (_undo.length > 50) _undo.removeAt(0);
    dirty = true;
  }

  void setValue(Scope s, int value) {
    _values[s.index] = clampSensitivity(value);
    dirty = true;
    revision++;
    notifyListeners();
  }

  void nudge(Scope s, int delta) {
    beginEdit();
    setValue(s, _values[s.index] + delta);
  }

  void setDpi(int? value) {
    beginEdit();
    dpi = value;
    revision++;
    notifyListeners();
  }

  void setFireSize(double percent) {
    fireSize = percent.clamp(50, 150).toDouble();
    dirty = true;
    notifyListeners();
  }

  void setFireOpacity(double value) {
    fireOpacity = value.clamp(0.2, 1.0).toDouble();
    dirty = true;
    notifyListeners();
  }

  void moveFire(double dx, double dy) {
    fireX = (fireX + dx).clamp(0.0, 1.0).toDouble();
    fireY = (fireY + dy).clamp(0.0, 1.0).toDouble();
    dirty = true;
    notifyListeners();
  }

  void undo() {
    if (_undo.isEmpty) return;
    _restore(_undo.removeLast());
    revision++;
    notifyListeners();
  }

  /// Back to the last seeded starting point.
  void reset() {
    _values = List<int>.of(_baseline);
    dpi = _baselineDpi;
    fireSize = defaultFireSize;
    fireX = defaultFireX;
    fireY = defaultFireY;
    fireOpacity = defaultFireOpacity;
    _undo.clear();
    dirty = false;
    revision++;
    notifyListeners();
  }
}
