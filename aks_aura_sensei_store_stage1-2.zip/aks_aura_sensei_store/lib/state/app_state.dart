import 'dart:convert';

import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';
import '../models/saved_profile.dart';
import '../services/billing_service.dart';
import '../services/device_service.dart';
import 'manual_draft.dart';

/// Play styles available without a subscription.
const Set<PlayStyle> kFreeStyles = {PlayStyle.balanced, PlayStyle.drag};

class AppState extends ChangeNotifier {
  AppState(
    this._prefs,
    this.db, {
    DeviceService? deviceService,
    BillingService? billing,
    DateTime Function()? now,
  })  : deviceService = deviceService ?? DeviceService(),
        billing = billing ?? const StubBillingService(),
        _now = now ?? DateTime.now {
    _loadPersisted();
  }

  static Future<AppState> load() async {
    final prefs = await SharedPreferences.getInstance();
    final json = await rootBundle.loadString('assets/devices.json');
    return AppState(prefs, DeviceDatabase.parse(json));
  }

  final SharedPreferences _prefs;
  final DeviceDatabase db;
  final DeviceService deviceService;
  final BillingService billing;
  final DateTime Function() _now;

  /// Editor state for the manual generator (lives here so other screens can
  /// push a profile into it).
  final ManualDraft draft = ManualDraft();

  bool signedIn = false;
  List<SavedProfile> profiles = [];
  DeviceResolution? device;
  int? _detectedDpi;
  int? smallestSidePx;

  /// Latest AI/engine result, kept for "compare with manual".
  SensitivityProfile? lastAi;

  // Entitlement. Only the billing stage (with server-side verification) may
  // set this to true. Debug builds can flip [debugPremium] for UI testing.
  bool _entitled = false;
  bool debugPremium = false;

  String _genDay = '';
  int _genCount = 0;

  // ------------------------------------------------------------ persistence

  void _loadPersisted() {
    signedIn = _prefs.getBool('signed_in') ?? false;
    final raw = _prefs.getString('profiles');
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List<dynamic>;
        profiles = [
          for (final e in list)
            SavedProfile.fromJson((e as Map).cast<String, Object?>()),
        ];
      } catch (_) {
        profiles = [];
      }
    }
    _genDay = _prefs.getString('gen_day') ?? '';
    _genCount = _prefs.getInt('gen_count') ?? 0;
    final ai = _prefs.getString('last_ai');
    if (ai != null) {
      try {
        lastAi = SensitivityProfile.fromJson(
            (jsonDecode(ai) as Map).cast<String, Object?>());
      } catch (_) {
        lastAi = null;
      }
    }
  }

  Future<void> _saveProfiles() => _prefs.setString(
      'profiles', jsonEncode(profiles.map((p) => p.toJson()).toList()));

  // ------------------------------------------------------------------- plan

  bool get premium => _entitled || (kDebugMode && debugPremium);

  void applyEntitlement(bool value) {
    _entitled = value;
    notifyListeners();
  }

  void setDebugPremium(bool value) {
    debugPremium = value;
    notifyListeners();
  }

  String _dayKey(DateTime d) => '${d.year}-${d.month}-${d.day}';

  int get remainingGenerations {
    if (premium) return 1 << 30;
    final used = _dayKey(_now()) == _genDay ? _genCount : 0;
    return (kFreeDailyGenerations - used).clamp(0, kFreeDailyGenerations).toInt();
  }

  /// Uses one generation. Returns false when the free daily limit is spent.
  bool consumeGeneration() {
    if (premium) return true;
    final today = _dayKey(_now());
    if (_genDay != today) {
      _genDay = today;
      _genCount = 0;
    }
    if (_genCount >= kFreeDailyGenerations) return false;
    _genCount++;
    _prefs.setString('gen_day', _genDay);
    _prefs.setInt('gen_count', _genCount);
    notifyListeners();
    return true;
  }

  bool canUseStyle(PlayStyle s) => premium || kFreeStyles.contains(s);

  bool get canSaveMore => premium || profiles.length < kFreeProfiles;

  // ------------------------------------------------------------------- auth

  Future<void> signInGuest() async {
    signedIn = true;
    await _prefs.setBool('signed_in', true);
    notifyListeners();
  }

  Future<void> signOut() async {
    signedIn = false;
    await _prefs.setBool('signed_in', false);
    notifyListeners();
  }

  /// Wipes everything stored on this device (profiles, limits, choices).
  /// Server-side deletion is added together with accounts in the backend stage.
  Future<void> deleteAllLocalData() async {
    await _prefs.clear();
    profiles = [];
    lastAi = null;
    signedIn = false;
    _genDay = '';
    _genCount = 0;
    debugPremium = false;
    draft.reset();
    notifyListeners();
  }

  // ----------------------------------------------------------------- device

  static const DeviceSpecs _unknownSpecs = DeviceSpecs(
    screenInches: 6.5,
    refreshHz: 60,
    ramGb: 4,
    chipsetTier: 3,
  );

  DeviceSpecs get specs => device?.specs ?? _unknownSpecs;

  String get deviceLabel {
    final d = device;
    if (d == null) return 'No device selected';
    final m = d.model;
    if (m != null) return m.name;
    final s = d.series;
    if (s != null) return '${s.name} (typical)';
    return 'Unlisted device';
  }

  /// Planner for the Android DPI guide, or null when it does not apply or the
  /// phone did not report enough information.
  DpiPlanner? get dpiPlanner {
    final dpi = specs.dpi;
    final side = smallestSidePx;
    if (!specs.dpiAdjustable || dpi == null || side == null) return null;
    return DpiPlanner(nativeDpi: dpi, smallestSidePx: side);
  }

  Future<void> init() async {
    await detectDevice(initial: true);
  }

  Future<void> detectDevice({bool initial = false}) async {
    final reading = await deviceService.detect();
    _detectedDpi = reading.device.dpi;
    smallestSidePx = reading.smallestSidePx;
    if (initial) {
      final sel = _prefs.getString('manual_sel');
      if (sel != null && _applySelection(sel)) return;
    } else {
      await _prefs.remove('manual_sel');
    }
    device = db.resolve(reading.device);
    _afterDeviceChange();
  }

  bool _applySelection(String sel) {
    final parts = sel.split('|');
    if (parts.length < 2) return false;
    try {
      device = db.specsFromSelection(
        brandId: parts[0],
        seriesId: parts[1],
        modelId: parts.length > 2 && parts[2].isNotEmpty ? parts[2] : null,
        dpi: _detectedDpi,
      );
      _afterDeviceChange();
      return true;
    } on ArgumentError {
      return false;
    }
  }

  Future<void> setManualDevice(
    String brandId,
    String seriesId,
    String? modelId,
  ) async {
    device = db.specsFromSelection(
      brandId: brandId,
      seriesId: seriesId,
      modelId: modelId,
      dpi: _detectedDpi,
    );
    await _prefs.setString('manual_sel', '$brandId|$seriesId|${modelId ?? ''}');
    _afterDeviceChange();
  }

  Future<void> setDeviceFromModel(DeviceModel m) =>
      setManualDevice(m.brandId, m.seriesId, m.id);

  void _afterDeviceChange() {
    draft.seed(baseRecommendation().profile, dpiValue: specs.dpi);
    notifyListeners();
  }

  // -------------------------------------------------------------- sensitivity

  static const SensitivityEngine _engine = SensitivityEngine();

  /// Free "device starting point": Balanced, Gold, 3-finger, no problems.
  SensitivityRecommendation baseRecommendation() =>
      _engine.recommend(specs, const PlayerInput());

  SensitivityRecommendation recommend(PlayerInput input) =>
      _engine.recommend(specs, input);

  Future<void> setLastAi(SensitivityProfile p) async {
    lastAi = p;
    await _prefs.setString('last_ai', jsonEncode(p.toJson()));
    notifyListeners();
  }

  // ----------------------------------------------------------------- profiles

  String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  SavedProfile profileFromDraft(String name) => SavedProfile(
        id: newId(),
        name: name,
        values: draft.profile,
        deviceLabel: deviceLabel,
        source: ProfileSource.manual,
        createdAt: _now(),
        dpi: draft.dpi,
        fireSizePercent: draft.fireSize,
        fireX: draft.fireX,
        fireY: draft.fireY,
        fireOpacity: draft.fireOpacity,
      );

  SavedProfile profileFromAi(String name, SensitivityProfile values) =>
      SavedProfile(
        id: newId(),
        name: name,
        values: values,
        deviceLabel: deviceLabel,
        source: ProfileSource.ai,
        createdAt: _now(),
        dpi: specs.dpi,
      );

  /// Returns false (and saves nothing) when the free plan is full.
  Future<bool> saveProfile(SavedProfile p) async {
    if (!canSaveMore) return false;
    profiles = [p, ...profiles];
    await _saveProfiles();
    notifyListeners();
    return true;
  }

  Future<void> renameProfile(String id, String name) async {
    profiles = [
      for (final p in profiles) p.id == id ? p.copyWith(name: name) : p,
    ];
    await _saveProfiles();
    notifyListeners();
  }

  Future<bool> duplicateProfile(String id) async {
    if (!canSaveMore) return false;
    final src = profiles.firstWhere((p) => p.id == id);
    final copy = src.copyWith(
      id: newId(),
      name: '${src.name} (copy)',
      createdAt: _now(),
    );
    profiles = [copy, ...profiles];
    await _saveProfiles();
    notifyListeners();
    return true;
  }

  Future<void> deleteProfile(String id) async {
    profiles = profiles.where((p) => p.id != id).toList();
    await _saveProfiles();
    notifyListeners();
  }
}

/// Gives every screen access to the [AppState] and rebuilds dependants when
/// it changes.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child})
      : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope missing above this widget');
    return scope!.notifier!;
  }
}
