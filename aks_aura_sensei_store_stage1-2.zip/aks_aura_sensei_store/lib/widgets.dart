import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:flutter/material.dart';

import 'config.dart';
import 'theme.dart';

class NeonCard extends StatelessWidget {
  const NeonCard({
    super.key,
    required this.child,
    this.accent = kBlue,
    this.padding = const EdgeInsets.all(16),
  });

  final Widget child;
  final Color accent;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: kPanel,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.45)),
        boxShadow: [
          BoxShadow(color: accent.withOpacity(0.14), blurRadius: 16),
        ],
      ),
      child: child,
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 18, 2, 8),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          color: kMuted,
          fontSize: 12,
          letterSpacing: 1.4,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

/// The honesty notice. Shown on every screen that produces numbers.
class DisclaimerBanner extends StatelessWidget {
  const DisclaimerBanner({super.key, this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    return NeonCard(
      accent: kRed,
      padding: const EdgeInsets.all(12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline, size: 18, color: kRed),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              compact ? kDisclaimerShort : kDisclaimerLong,
              style: const TextStyle(fontSize: 12, color: kMuted, height: 1.35),
            ),
          ),
        ],
      ),
    );
  }
}

/// The six values as a 3 x 2 grid.
class SensGrid extends StatelessWidget {
  const SensGrid({super.key, required this.profile, this.compare});

  final SensitivityProfile profile;

  /// When set, shows the difference against this profile under each value.
  final SensitivityProfile? compare;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      const gap = 8.0;
      final w = (box.maxWidth - gap * 2) / 3;
      return Wrap(
        spacing: gap,
        runSpacing: gap,
        children: [
          for (final s in Scope.values)
            SizedBox(
              width: w,
              child: _SensTile(
                label: s.label,
                value: profile[s],
                delta: compare == null ? null : profile[s] - compare![s],
              ),
            ),
        ],
      );
    });
  }
}

class _SensTile extends StatelessWidget {
  const _SensTile({required this.label, required this.value, this.delta});

  final String label;
  final int value;
  final int? delta;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: kBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBlue.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, color: kMuted)),
          const SizedBox(height: 4),
          Text('$value',
              style: const TextStyle(
                  fontSize: 26, fontWeight: FontWeight.w800, color: kBlue)),
          if (delta != null)
            Text(
              delta == 0 ? 'same' : (delta! > 0 ? '+$delta' : '$delta'),
              style: TextStyle(
                fontSize: 11,
                color: delta == 0 ? kMuted : (delta! > 0 ? kRed : kBlue),
              ),
            ),
        ],
      ),
    );
  }
}

class PlanBadge extends StatelessWidget {
  const PlanBadge({super.key, required this.premium});

  final bool premium;

  @override
  Widget build(BuildContext context) {
    final color = premium ? kRed : kMuted;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Text(
        premium ? 'PREMIUM' : 'FREE',
        style: TextStyle(
            color: color, fontSize: 11, fontWeight: FontWeight.w800),
      ),
    );
  }
}

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

/// Asks for a short text (profile name). Returns null when cancelled.
Future<String?> promptText(
  BuildContext context, {
  required String title,
  String initial = '',
}) {
  return showDialog<String>(
    context: context,
    builder: (_) => _TextPromptDialog(title: title, initial: initial),
  );
}

class _TextPromptDialog extends StatefulWidget {
  const _TextPromptDialog({required this.title, required this.initial});

  final String title;
  final String initial;

  @override
  State<_TextPromptDialog> createState() => _TextPromptDialogState();
}

class _TextPromptDialogState extends State<_TextPromptDialog> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: kPanel,
      title: Text(widget.title),
      content: TextField(
        controller: _controller,
        autofocus: true,
        maxLength: 40,
        textInputAction: TextInputAction.done,
        onSubmitted: (v) => Navigator.of(context).pop(v.trim()),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(_controller.text.trim()),
          child: const Text('OK'),
        ),
      ],
    );
  }
}

/// Side-by-side table of two profiles.
Future<void> showCompareDialog(
  BuildContext context, {
  required String aLabel,
  required SensitivityProfile a,
  required String bLabel,
  required SensitivityProfile b,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) => AlertDialog(
      backgroundColor: kPanel,
      title: const Text('Compare'),
      content: Table(
        columnWidths: const {0: FlexColumnWidth(2)},
        children: [
          TableRow(children: [
            const SizedBox.shrink(),
            _cell(aLabel, bold: true),
            _cell(bLabel, bold: true),
            _cell('Diff', bold: true),
          ]),
          for (final s in Scope.values)
            TableRow(children: [
              _cell(s.label, align: TextAlign.left),
              _cell('${a[s]}'),
              _cell('${b[s]}'),
              _cell(a[s] == b[s] ? '-' : '${a[s] - b[s] > 0 ? '+' : ''}${a[s] - b[s]}'),
            ]),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    ),
  );
}

Widget _cell(String text, {bool bold = false, TextAlign align = TextAlign.center}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
    child: Text(
      text,
      textAlign: align,
      style: TextStyle(
        fontSize: 13,
        fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
      ),
    ),
  );
}
