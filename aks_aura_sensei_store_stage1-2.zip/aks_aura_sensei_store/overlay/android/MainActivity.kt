package com.aksaura.aks_aura_sensei_store

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlin.math.sqrt

/**
 * Device detection for AKS AURA SENSEI STORE.
 *
 * Reads only what Android exposes without any permission: build info, display
 * metrics, supported refresh rates and total RAM. Android has no public API
 * for touch sampling rate or chipset tier, so those come from the device list
 * in Dart. Nothing here is sent anywhere.
 */
class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "aks/device")
            .setMethodCallHandler { call, result ->
                if (call.method == "getDeviceInfo") {
                    try {
                        result.success(collect())
                    } catch (e: Exception) {
                        result.error("detect_failed", e.message, null)
                    }
                } else {
                    result.notImplemented()
                }
            }
    }

    @Suppress("DEPRECATION")
    private fun collect(): Map<String, Any?> {
        val displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)

        val xdpi = if (metrics.xdpi > 0f) metrics.xdpi.toDouble() else metrics.densityDpi.toDouble()
        val ydpi = if (metrics.ydpi > 0f) metrics.ydpi.toDouble() else metrics.densityDpi.toDouble()
        val widthIn = metrics.widthPixels / xdpi
        val heightIn = metrics.heightPixels / ydpi
        val inches = Math.round(sqrt(widthIn * widthIn + heightIn * heightIn) * 10.0) / 10.0

        // Highest refresh rate the panel supports, not the momentary rate.
        val maxHz: Float = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            display.supportedModes.maxOf { it.refreshRate }
        } else {
            display.refreshRate
        }

        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        val ramGb = memoryInfo.totalMem / (1024.0 * 1024.0 * 1024.0)

        return mapOf(
            "manufacturer" to Build.MANUFACTURER,
            "brand" to Build.BRAND,
            "model" to Build.MODEL,
            "device" to Build.DEVICE,
            "sdk" to Build.VERSION.SDK_INT,
            "screenInches" to inches,
            "maxRefreshHz" to maxHz.toDouble(),
            "ramGb" to ramGb,
            "dpi" to metrics.densityDpi,
            "widthPx" to metrics.widthPixels,
            "heightPx" to metrics.heightPixels,
        )
    }
}
