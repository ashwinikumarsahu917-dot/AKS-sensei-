# AKS AURA SENSEI STORE

Two packages + a CI workflow:

| Folder | What it is | Status |
|---|---|---|
| `aks_sensei_core/` | Pure-Dart device database (45 brands, 147 series, 247 seed models, every iPhone to the 17 series + 18 Pro), 0-200 sensitivity engine, DPI planner, strict AI-response validator. | Stage 1, unit-tested |
| `aks_aura_sensei_store/` | Flutter app: splash, login, home, device detect, AI generator (offline engine), manual generator, saved profiles, paywall, settings. Kotlin device-detection module. | Stage 2, builds in CI |
| `.github/workflows/build-apk.yml` | Runs core tests, app analyze + tests, builds the APK and an AAB. | ready |

## Get the APK (no PC needed)
1. Create a GitHub repo and upload these three items (folders `aks_sensei_core`, `aks_aura_sensei_store`, `.github`) keeping the same layout.
2. Repo > **Actions** > **Build Android APK** > **Run workflow**.
3. When it finishes, open the run and download the **aks-aura-sensei-store-apk** artifact. Unzip, install `app-release.apk`.

The first CI run is also the first time this code is compiled with the real Flutter SDK. If a step fails, the log names the file and line; send it back and I will fix it.

## Build locally
```
cd aks_sensei_core && dart pub get && dart test
cd ../aks_aura_sensei_store
bash tool/bootstrap.sh        # generates android/ + ios/, adds the Kotlin module
flutter pub get
flutter analyze && flutter test
flutter build apk --release
```
The APK from `flutter build apk` is signed with Flutter's debug key: fine for installing and testing, **not** accepted by Google Play. A Play upload needs your own upload keystore (Stage 5).

## What is real and what is a stub
- Real: device detection, device DB, sensitivity engine, DPI guide, manual editor, saved profiles, share-as-image, free-plan limits, local data deletion.
- Stub (clearly labelled in the UI): Google/Apple sign-in (needs your Firebase project files), subscriptions (needs Play Console products + server verification), the LLM "AI" (this build uses the offline engine), cloud sync, Hindi chat.
- The free-plan daily limit is enforced on the phone for now; the backend stage re-checks it on the server.

## Data caveat
`aks_sensei_core/assets/devices.json` is **seed data written from memory**. Verify specs against manufacturer pages before release. Rows are marked `unverified` where I was not sure. Edit `tool/build_devices.py` (or the JSON) and re-run `python3 tool/build_devices.py`.
