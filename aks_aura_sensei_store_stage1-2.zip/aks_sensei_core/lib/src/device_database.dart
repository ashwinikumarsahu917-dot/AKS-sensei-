/// Remote-updatable device database (Brand → Series → Model).
///
/// The JSON is data, not code: the app ships a bundled seed and replaces it
/// with a newer signed copy from the backend, so new phones never need an app
/// release. See `assets/devices.json` and the README for the schema.
library;

import 'dart:convert';

import 'models.dart';

/// Highest JSON schema version this parser understands.
const int kSupportedSchema = 1;

/// Lower-case alphanumerics only; "+" becomes "plus" so "Galaxy S24+" and
/// "Galaxy S24" stay different: "Redmi Note 13 Pro+" → "redminote13proplus".
String normalizeName(String s) => s
    .toLowerCase()
    .replaceAll('+', 'plus')
    .replaceAll(RegExp(r'[^a-z0-9]'), '');

/// Upper-case, whitespace removed, punctuation kept: "sm-s928b" → "SM-S928B".
/// (Punctuation matters: "iPhone1,1" and "iPhone11" are different devices.)
String normalizeCode(String s) => s.toUpperCase().replaceAll(RegExp(r'\s+'), '');

/// Rough tier guess when nothing else is known (unknown Android device).
int estimateTierFromRam(double ramGb) {
  if (ramGb <= 3) return 1;
  if (ramGb <= 4) return 2;
  if (ramGb <= 6) return 3;
  if (ramGb <= 8) return 4;
  return 5;
}

const List<double> _kMarketedRamGb = [
  0.5, 1, 1.5, 2, 3, 4, 6, 8, 12, 16, 18, 24,
];

/// Android reports *usable* RAM (an "8 GB" phone shows ~7.4). Snap to the
/// marketed size.
double roundRamToMarketed(double measuredGb) {
  for (final size in _kMarketedRamGb) {
    if (size >= measuredGb - 0.05) return size;
  }
  return _kMarketedRamGb.last;
}

class DeviceModel {
  const DeviceModel({
    required this.id,
    required this.name,
    required this.brandId,
    required this.brandName,
    required this.seriesId,
    required this.seriesName,
    required this.specs,
    this.codes = const <String>[],
    this.unverified = false,
  });

  final String id;
  final String name;
  final String brandId;
  final String brandName;
  final String seriesId;
  final String seriesName;
  final DeviceSpecs specs;

  /// Android `Build.MODEL` values or iOS `utsname.machine` identifiers.
  final List<String> codes;

  /// True when the specs still need checking against a trusted source.
  final bool unverified;

  String get key => '$brandId/$seriesId/$id';
}

class DeviceSeries {
  const DeviceSeries({
    required this.id,
    required this.name,
    required this.brandId,
    required this.specs,
    required this.models,
  });

  final String id;
  final String name;
  final String brandId;

  /// Typical values for the series; models inherit and override them.
  final DeviceSpecs specs;
  final List<DeviceModel> models;
}

class DeviceBrand {
  const DeviceBrand({
    required this.id,
    required this.name,
    required this.platform,
    required this.series,
    this.aliases = const <String>[],
  });

  final String id;
  final String name;
  final DevicePlatform platform;
  final List<DeviceSeries> series;

  /// Other names that may prefix a model string ("Xiaomi" for Redmi/POCO).
  final List<String> aliases;
}

/// What the native layer (Kotlin / Swift) reports about the running device.
class DetectedDevice {
  const DetectedDevice({
    this.manufacturer,
    this.modelCode,
    this.marketingName,
    this.screenInches,
    this.maxRefreshHz,
    this.ramGb,
    this.dpi,
    this.platform = DevicePlatform.android,
  });

  final String? manufacturer;

  /// Android `Build.MODEL` or iOS `utsname.machine`.
  final String? modelCode;
  final String? marketingName;

  /// Computed from display metrics (approximate).
  final double? screenInches;

  /// Highest supported display mode, not the momentary rate.
  final int? maxRefreshHz;

  /// Raw total RAM in GB as reported by the OS.
  final double? ramGb;
  final int? dpi;
  final DevicePlatform platform;
}

enum MatchLevel {
  /// Matched by `Build.MODEL` / iOS identifier.
  exactCode,

  /// Matched by marketing name.
  exactName,

  /// User picked Brand → Series → Model.
  manualModel,

  /// User picked only Brand → Series; specs are typical values.
  seriesDefaults,

  /// Not in the database: measured values + RAM-based tier guess.
  genericFallback,
}

class DeviceResolution {
  const DeviceResolution({
    required this.specs,
    required this.level,
    this.model,
    this.series,
    this.notes = const <String>[],
  });

  final DeviceSpecs specs;
  final MatchLevel level;
  final DeviceModel? model;
  final DeviceSeries? series;
  final List<String> notes;

  /// True when the UI should say "approximate" and invite a manual pick.
  bool get isApproximate =>
      level == MatchLevel.seriesDefaults ||
      level == MatchLevel.genericFallback;
}

class DeviceDatabase {
  DeviceDatabase._({
    required this.schema,
    required this.version,
    required this.brands,
  })  : _byCode = {},
        _byName = {},
        _prefixes = {} {
    for (final b in brands) {
      _prefixes
        ..add(normalizeName(b.name))
        ..add(normalizeName(b.id))
        ..addAll(b.aliases.map(normalizeName));
      for (final s in b.series) {
        for (final m in s.models) {
          for (final c in m.codes) {
            _byCode.putIfAbsent(normalizeCode(c), () => m);
          }
          _byName.putIfAbsent(normalizeName(m.name), () => m);
        }
      }
    }
    _prefixes.removeWhere((p) => p.isEmpty);
  }

  final int schema;
  final String version;
  final List<DeviceBrand> brands;

  final Map<String, DeviceModel> _byCode;
  final Map<String, DeviceModel> _byName;
  final Set<String> _prefixes;

  factory DeviceDatabase.parse(String jsonText) {
    final Object? decoded;
    try {
      decoded = jsonDecode(jsonText);
    } on FormatException catch (e) {
      throw FormatException('devices.json is not valid JSON: ${e.message}');
    }
    return DeviceDatabase.fromJson(_asMap(decoded, 'root'));
  }

  factory DeviceDatabase.fromJson(Map<String, Object?> json) {
    final schema = json['schema'];
    if (schema is! int) _bad('root', '"schema" must be an integer');
    if (schema > kSupportedSchema) {
      _bad('root', 'schema $schema is newer than supported $kSupportedSchema');
    }
    final version = json['version'];
    if (version is! String || version.isEmpty) {
      _bad('root', '"version" must be a non-empty string');
    }
    final rawBrands = json['brands'];
    if (rawBrands is! List) _bad('root', '"brands" must be a list');

    final brands = <DeviceBrand>[];
    for (var i = 0; i < rawBrands.length; i++) {
      brands.add(_parseBrand(_asMap(rawBrands[i], 'brands[$i]'), 'brands[$i]'));
    }
    return DeviceDatabase._(schema: schema, version: version, brands: brands);
  }

  // ---------------------------------------------------------------- queries

  Iterable<DeviceSeries> get allSeries sync* {
    for (final b in brands) {
      yield* b.series;
    }
  }

  Iterable<DeviceModel> get allModels sync* {
    for (final s in allSeries) {
      yield* s.models;
    }
  }

  DeviceBrand? brand(String id) {
    for (final b in brands) {
      if (b.id == id) return b;
    }
    return null;
  }

  DeviceSeries? series(String brandId, String seriesId) {
    final b = brand(brandId);
    if (b == null) return null;
    for (final s in b.series) {
      if (s.id == seriesId) return s;
    }
    return null;
  }

  DeviceModel? model(String brandId, String seriesId, String modelId) {
    final s = series(brandId, seriesId);
    if (s == null) return null;
    for (final m in s.models) {
      if (m.id == modelId) return m;
    }
    return null;
  }

  /// Exact match on `Build.MODEL` / iOS identifier (case and spaces ignored).
  DeviceModel? findByCode(String code) => _byCode[normalizeCode(code)];

  /// Exact match on marketing name; a leading brand name is ignored
  /// ("Samsung Galaxy S24 Ultra" == "Galaxy S24 Ultra"). Deliberately not a
  /// fuzzy match: wrong specs are worse than "not found".
  DeviceModel? findByName(String query) {
    final q = normalizeName(query);
    if (q.isEmpty) return null;
    final direct = _byName[q];
    if (direct != null) return direct;
    for (final prefix in _prefixes) {
      if (q.length > prefix.length && q.startsWith(prefix)) {
        final hit = _byName[q.substring(prefix.length)];
        if (hit != null) return hit;
      }
    }
    return null;
  }

  /// Search box for the manual selector: names starting with the query first,
  /// then names containing it.
  List<DeviceModel> searchModels(String query, {int limit = 20}) {
    final q = normalizeName(query);
    if (q.isEmpty) return const <DeviceModel>[];
    final starts = <DeviceModel>[];
    final contains = <DeviceModel>[];
    for (final m in allModels) {
      final n = normalizeName(m.name);
      if (n.startsWith(q)) {
        starts.add(m);
      } else if (n.contains(q)) {
        contains.add(m);
      }
    }
    return [...starts, ...contains].take(limit).toList();
  }

  /// Auto-detect path. Measured values that the OS reports reliably (max
  /// refresh rate, RAM) override the database; everything the OS can't tell
  /// us (touch sampling rate, chipset tier) comes from the database.
  DeviceResolution resolve(DetectedDevice d) {
    DeviceModel? hit;
    var level = MatchLevel.genericFallback;

    final code = d.modelCode;
    if (code != null && code.trim().isNotEmpty) {
      hit = findByCode(code);
      if (hit != null) level = MatchLevel.exactCode;
    }
    if (hit == null) {
      for (final candidate in [d.marketingName, d.modelCode]) {
        if (candidate == null || candidate.trim().isEmpty) continue;
        final byName = findByName(candidate);
        if (byName != null) {
          hit = byName;
          level = MatchLevel.exactName;
          break;
        }
      }
    }

    final base = hit?.specs;
    final ram = d.ramGb != null
        ? roundRamToMarketed(d.ramGb!)
        : (base?.ramGb ?? 4.0);
    final unknownTier = d.platform == DevicePlatform.ios
        ? 5
        : estimateTierFromRam(ram);

    final specs = DeviceSpecs(
      screenInches: base?.screenInches ?? d.screenInches ?? 6.5,
      refreshHz: d.maxRefreshHz ?? base?.refreshHz ?? 60,
      ramGb: ram,
      chipsetTier: base?.chipsetTier ?? unknownTier,
      touchSamplingHz: base?.touchSamplingHz,
      platform: d.platform,
      dpi: d.dpi,
    );

    final notes = <String>[];
    if (hit == null) {
      notes.add('This device is not in the database yet. Values were '
          'measured on the phone; pick your model manually for a closer match.');
    } else if (hit.unverified) {
      notes.add('Specs for this model are not verified yet.');
    }
    return DeviceResolution(
      specs: specs,
      level: level,
      model: hit,
      notes: notes,
    );
  }

  /// Manual fallback path (Brand → Series → optional Model).
  DeviceResolution specsFromSelection({
    required String brandId,
    required String seriesId,
    String? modelId,
    int? dpi,
  }) {
    final s = series(brandId, seriesId);
    if (s == null) {
      throw ArgumentError('Unknown series $brandId/$seriesId');
    }
    if (modelId != null) {
      final m = model(brandId, seriesId, modelId);
      if (m == null) {
        throw ArgumentError('Unknown model $brandId/$seriesId/$modelId');
      }
      return DeviceResolution(
        specs: m.specs.copyWith(dpi: dpi),
        level: MatchLevel.manualModel,
        model: m,
        series: s,
        notes: m.unverified
            ? const ['Specs for this model are not verified yet.']
            : const <String>[],
      );
    }
    return DeviceResolution(
      specs: s.specs.copyWith(dpi: dpi),
      level: MatchLevel.seriesDefaults,
      series: s,
      notes: const [
        'Typical values for this series were used. Pick your exact model '
            'for a closer match.',
      ],
    );
  }

  // ------------------------------------------------------------- validation

  /// Returns human-readable problems; empty means the database is healthy.
  /// Run it on every downloaded update BEFORE swapping it in.
  List<String> validate() {
    final issues = <String>[];
    final brandIds = <String>{};
    final codes = <String, String>{};

    void checkSpecs(DeviceSpecs s, String ctx) {
      if (s.screenInches < 3.0 || s.screenInches > 13.0) {
        issues.add('$ctx: screen ${s.screenInches}" out of range 3–13');
      }
      if (s.refreshHz < 24 || s.refreshHz > 240) {
        issues.add('$ctx: refresh ${s.refreshHz}Hz out of range 24–240');
      }
      if (s.ramGb < 0.1 || s.ramGb > 24) {
        issues.add('$ctx: RAM ${s.ramGb}GB out of range 0.1–24');
      }
      if (s.chipsetTier < 1 || s.chipsetTier > 5) {
        issues.add('$ctx: tier ${s.chipsetTier} out of range 1–5');
      }
      final t = s.touchSamplingHz;
      if (t != null && (t < 60 || t > 1500)) {
        issues.add('$ctx: touch ${t}Hz out of range 60–1500');
      }
    }

    for (final b in brands) {
      if (!brandIds.add(b.id)) issues.add('duplicate brand id "${b.id}"');
      if (b.series.isEmpty) issues.add('brand "${b.id}" has no series');
      final seriesIds = <String>{};
      for (final s in b.series) {
        final sctx = '${b.id}/${s.id}';
        if (!seriesIds.add(s.id)) issues.add('duplicate series id "$sctx"');
        checkSpecs(s.specs, sctx);
        final modelIds = <String>{};
        for (final m in s.models) {
          if (!modelIds.add(m.id)) issues.add('duplicate model id "${m.key}"');
          checkSpecs(m.specs, m.key);
          for (final c in m.codes) {
            final prev = codes[normalizeCode(c)];
            if (prev != null && prev != m.key) {
              issues.add('code "$c" used by both $prev and ${m.key}');
            } else {
              codes[normalizeCode(c)] = m.key;
            }
          }
        }
      }
    }
    return issues;
  }
}

// ---------------------------------------------------------------- parsing

Never _bad(String ctx, String msg) =>
    throw FormatException('devices.json $ctx: $msg');

Map<String, Object?> _asMap(Object? v, String ctx) {
  if (v is Map) return v.cast<String, Object?>();
  _bad(ctx, 'expected an object');
}

String _reqString(Map<String, Object?> m, String key, String ctx) {
  final v = m[key];
  if (v is! String || v.trim().isEmpty) {
    _bad(ctx, '"$key" must be a non-empty string');
  }
  return v.trim();
}

double? _optNum(Map<String, Object?> m, String key, String ctx) {
  final v = m[key];
  if (v == null) return null;
  if (v is! num) _bad(ctx, '"$key" must be a number');
  if (!v.isFinite) _bad(ctx, '"$key" must be finite');
  return v.toDouble();
}

DeviceSpecs _specsFrom(
  Map<String, Object?> m,
  String ctx,
  DevicePlatform platform, {
  DeviceSpecs? parent,
}) {
  final inches = _optNum(m, 'in', ctx) ?? parent?.screenInches;
  final hz = _optNum(m, 'hz', ctx)?.round() ?? parent?.refreshHz;
  final ram = _optNum(m, 'ram', ctx) ?? parent?.ramGb;
  final tier = _optNum(m, 'tier', ctx)?.round() ?? parent?.chipsetTier;
  final touch = _optNum(m, 'touch', ctx)?.round() ?? parent?.touchSamplingHz;
  if (inches == null) _bad(ctx, 'missing "in" (screen inches)');
  if (hz == null) _bad(ctx, 'missing "hz" (refresh rate)');
  if (ram == null) _bad(ctx, 'missing "ram" (GB)');
  if (tier == null) _bad(ctx, 'missing "tier" (1-5)');
  return DeviceSpecs(
    screenInches: inches,
    refreshHz: hz,
    ramGb: ram,
    chipsetTier: tier,
    touchSamplingHz: touch,
    platform: platform,
  );
}

String _slug(String s) => s
    .toLowerCase()
    .replaceAll('+', ' plus')
    .replaceAll(RegExp(r'[^a-z0-9]+'), '-')
    .replaceAll(RegExp(r'^-+|-+$'), '');

DeviceBrand _parseBrand(Map<String, Object?> m, String ctx) {
  final id = _reqString(m, 'id', ctx);
  final name = _reqString(m, 'name', ctx);
  final bctx = 'brand "$id"';
  final platformRaw = m['platform'] ?? 'android';
  final platform = switch (platformRaw) {
    'android' => DevicePlatform.android,
    'ios' => DevicePlatform.ios,
    _ => _bad(bctx, '"platform" must be "android" or "ios"'),
  };
  final aliasesRaw = m['aliases'];
  final aliases = <String>[
    if (aliasesRaw is List)
      for (final a in aliasesRaw)
        if (a is String) a,
  ];
  final rawSeries = m['series'];
  if (rawSeries is! List) _bad(bctx, '"series" must be a list');

  final series = <DeviceSeries>[];
  for (var i = 0; i < rawSeries.length; i++) {
    series.add(_parseSeries(
      _asMap(rawSeries[i], '$bctx series[$i]'),
      id,
      name,
      platform,
    ));
  }
  return DeviceBrand(
    id: id,
    name: name,
    platform: platform,
    series: series,
    aliases: aliases,
  );
}

DeviceSeries _parseSeries(
  Map<String, Object?> m,
  String brandId,
  String brandName,
  DevicePlatform platform,
) {
  final id = _reqString(m, 'id', 'brand "$brandId" series');
  final name = _reqString(m, 'name', 'brand "$brandId" series');
  final sctx = 'series "$brandId/$id"';
  final specs = _specsFrom(m, sctx, platform);

  final rawModels = m['models'];
  final models = <DeviceModel>[];
  if (rawModels != null) {
    if (rawModels is! List) _bad(sctx, '"models" must be a list');
    for (var i = 0; i < rawModels.length; i++) {
      final mm = _asMap(rawModels[i], '$sctx models[$i]');
      final mname = _reqString(mm, 'name', '$sctx models[$i]');
      final mid = (mm['id'] is String && (mm['id'] as String).isNotEmpty)
          ? mm['id'] as String
          : _slug(mname);
      final codesRaw = mm['codes'];
      models.add(DeviceModel(
        id: mid,
        name: mname,
        brandId: brandId,
        brandName: brandName,
        seriesId: id,
        seriesName: name,
        specs: _specsFrom(mm, '$sctx model "$mname"', platform, parent: specs),
        codes: <String>[
          if (codesRaw is List)
            for (final c in codesRaw)
              if (c is String && c.trim().isNotEmpty) c.trim(),
        ],
        unverified: mm['unverified'] == true,
      ));
    }
  }
  return DeviceSeries(
    id: id,
    name: name,
    brandId: brandId,
    specs: specs,
    models: models,
  );
}
