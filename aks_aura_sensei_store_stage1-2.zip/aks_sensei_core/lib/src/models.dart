/// Core value types for AKS AURA SENSEI STORE.
///
/// Pure Dart (no Flutter imports) so everything here is unit-testable with
/// `dart test` and reusable from the Flutter app, a backend or a CLI.
library;

import 'dart:convert';

/// Lowest / highest value a sensitivity slider can take in this app.
const int kSensitivityMin = 0;
const int kSensitivityMax = 200;

/// Rounds [value] to the nearest integer and clamps it to 0–200.
///
/// Throws [ArgumentError] for NaN / infinity so garbage never becomes a
/// "valid-looking" number.
int clampSensitivity(num value) {
  final d = value.toDouble();
  if (!d.isFinite) {
    throw ArgumentError.value(value, 'value', 'must be a finite number');
  }
  if (d <= kSensitivityMin) return kSensitivityMin;
  if (d >= kSensitivityMax) return kSensitivityMax;
  return d.round();
}

enum DevicePlatform { android, ios }

enum PlayStyle { drag, brazilianFreestyle, desertEagle, ump, awm, balanced }

enum FingerSetup { twoFinger, threeFinger, fourFinger, claw }

enum Problem { overshoot, tooSlow, shaky, recoil }

/// Ordered low → high. The order is used by the engine (index-based modifier).
enum Rank { bronze, silver, gold, platinum, diamond, heroic, grandmaster }

/// The six values the player types into Free Fire's sensitivity screen.
enum Scope { general, redDot, scope2x, scope4x, awm, freeLook }

extension ScopeX on Scope {
  /// Stable key used in JSON (device DB, AI proxy, cloud sync).
  String get jsonKey => switch (this) {
        Scope.general => 'general',
        Scope.redDot => 'red_dot',
        Scope.scope2x => 'scope_2x',
        Scope.scope4x => 'scope_4x',
        Scope.awm => 'awm',
        Scope.freeLook => 'free_look',
      };

  String get label => switch (this) {
        Scope.general => 'General',
        Scope.redDot => 'Red Dot',
        Scope.scope2x => '2x Scope',
        Scope.scope4x => '4x Scope',
        Scope.awm => 'AWM / Sniper',
        Scope.freeLook => 'Free Look',
      };
}

extension PlayStyleX on PlayStyle {
  String get label => switch (this) {
        PlayStyle.drag => 'Drag',
        PlayStyle.brazilianFreestyle => 'Brazilian Freestyle',
        PlayStyle.desertEagle => 'Desert Eagle',
        PlayStyle.ump => 'UMP',
        PlayStyle.awm => 'AWM',
        PlayStyle.balanced => 'Balanced',
      };
}

extension FingerSetupX on FingerSetup {
  String get label => switch (this) {
        FingerSetup.twoFinger => '2-finger',
        FingerSetup.threeFinger => '3-finger',
        FingerSetup.fourFinger => '4-finger',
        FingerSetup.claw => 'Claw',
      };
}

extension RankX on Rank {
  String get label => switch (this) {
        Rank.bronze => 'Bronze',
        Rank.silver => 'Silver',
        Rank.gold => 'Gold',
        Rank.platinum => 'Platinum',
        Rank.diamond => 'Diamond',
        Rank.heroic => 'Heroic',
        Rank.grandmaster => 'Grandmaster',
      };
}

extension ProblemX on Problem {
  String get label => switch (this) {
        Problem.overshoot => 'Overshooting',
        Problem.tooSlow => 'Too slow',
        Problem.shaky => 'Shaky aim',
        Problem.recoil => 'Recoil control',
      };
}

/// Hardware facts the engine needs.
class DeviceSpecs {
  const DeviceSpecs({
    required this.screenInches,
    required this.refreshHz,
    required this.ramGb,
    required this.chipsetTier,
    this.touchSamplingHz,
    this.platform = DevicePlatform.android,
    this.dpi,
  });

  /// Physical screen diagonal in inches.
  final double screenInches;

  /// Highest refresh rate the panel supports (not the momentary rate).
  final int refreshHz;

  /// Marketed RAM in GB (fractions allowed for very old devices).
  final double ramGb;

  /// 1 (entry) … 5 (flagship). See README for the tier legend.
  final int chipsetTier;

  /// Touch sampling rate, or null when unknown. Android exposes no API for
  /// this, so it normally comes from the device DB.
  final int? touchSamplingHz;

  final DevicePlatform platform;

  /// Current display density in dpi (informational; Android only).
  final int? dpi;

  /// iPhone DPI is fixed, so the UI shows "N/A" there.
  bool get dpiAdjustable => platform == DevicePlatform.android;

  /// Touch rate used by the engine: the known value, otherwise an estimate.
  int get effectiveTouchSamplingHz {
    final known = touchSamplingHz;
    if (known != null) return known;
    if (platform == DevicePlatform.ios) {
      return (refreshHz * 2).clamp(120, 240).toInt();
    }
    return 120 + (chipsetTier.clamp(1, 5).toInt() - 1) * 90;
  }

  DeviceSpecs copyWith({
    double? screenInches,
    int? refreshHz,
    double? ramGb,
    int? chipsetTier,
    int? touchSamplingHz,
    DevicePlatform? platform,
    int? dpi,
  }) {
    return DeviceSpecs(
      screenInches: screenInches ?? this.screenInches,
      refreshHz: refreshHz ?? this.refreshHz,
      ramGb: ramGb ?? this.ramGb,
      chipsetTier: chipsetTier ?? this.chipsetTier,
      touchSamplingHz: touchSamplingHz ?? this.touchSamplingHz,
      platform: platform ?? this.platform,
      dpi: dpi ?? this.dpi,
    );
  }

  @override
  String toString() =>
      'DeviceSpecs(${screenInches}in, ${refreshHz}Hz, touch=$touchSamplingHz, '
      '${ramGb}GB, tier=$chipsetTier, $platform, dpi=$dpi)';
}

/// The six sensitivity values. Every value is an int clamped to 0–200.
class SensitivityProfile {
  SensitivityProfile({
    required num general,
    required num redDot,
    required num scope2x,
    required num scope4x,
    required num awm,
    required num freeLook,
  })  : general = clampSensitivity(general),
        redDot = clampSensitivity(redDot),
        scope2x = clampSensitivity(scope2x),
        scope4x = clampSensitivity(scope4x),
        awm = clampSensitivity(awm),
        freeLook = clampSensitivity(freeLook);

  final int general;
  final int redDot;
  final int scope2x;
  final int scope4x;
  final int awm;
  final int freeLook;

  int operator [](Scope scope) => switch (scope) {
        Scope.general => general,
        Scope.redDot => redDot,
        Scope.scope2x => scope2x,
        Scope.scope4x => scope4x,
        Scope.awm => awm,
        Scope.freeLook => freeLook,
      };

  Map<String, int> toJson() => {
        for (final s in Scope.values) s.jsonKey: this[s],
      };

  /// Strict: every key must be present and numeric. Values are rounded and
  /// clamped to 0–200. Unknown keys are ignored.
  factory SensitivityProfile.fromJson(Map<String, Object?> json) {
    num read(Scope s) {
      final v = json[s.jsonKey];
      if (v is! num) {
        throw FormatException('Missing or non-numeric "${s.jsonKey}"');
      }
      if (!v.isFinite) {
        throw FormatException('"${s.jsonKey}" must be finite');
      }
      return v;
    }

    return SensitivityProfile(
      general: read(Scope.general),
      redDot: read(Scope.redDot),
      scope2x: read(Scope.scope2x),
      scope4x: read(Scope.scope4x),
      awm: read(Scope.awm),
      freeLook: read(Scope.freeLook),
    );
  }

  SensitivityProfile copyWith({
    num? general,
    num? redDot,
    num? scope2x,
    num? scope4x,
    num? awm,
    num? freeLook,
  }) {
    return SensitivityProfile(
      general: general ?? this.general,
      redDot: redDot ?? this.redDot,
      scope2x: scope2x ?? this.scope2x,
      scope4x: scope4x ?? this.scope4x,
      awm: awm ?? this.awm,
      freeLook: freeLook ?? this.freeLook,
    );
  }

  /// Copy with one scope replaced (value is rounded and clamped to 0–200).
  SensitivityProfile withScope(Scope scope, num value) => switch (scope) {
        Scope.general => copyWith(general: value),
        Scope.redDot => copyWith(redDot: value),
        Scope.scope2x => copyWith(scope2x: value),
        Scope.scope4x => copyWith(scope4x: value),
        Scope.awm => copyWith(awm: value),
        Scope.freeLook => copyWith(freeLook: value),
      };

  @override
  bool operator ==(Object other) =>
      other is SensitivityProfile &&
      other.general == general &&
      other.redDot == redDot &&
      other.scope2x == scope2x &&
      other.scope4x == scope4x &&
      other.awm == awm &&
      other.freeLook == freeLook;

  @override
  int get hashCode =>
      Object.hash(general, redDot, scope2x, scope4x, awm, freeLook);

  @override
  String toString() =>
      'SensitivityProfile(general=$general, redDot=$redDot, 2x=$scope2x, '
      '4x=$scope4x, awm=$awm, freeLook=$freeLook)';
}

/// What the backend LLM must return (see `docs` in the AI stage):
///
/// ```json
/// {"general":100,"red_dot":96,"scope_2x":92,"scope_4x":86,"awm":72,
///  "free_look":94,
///  "explanations":{"general":"…","red_dot":"…"}}
/// ```
///
/// The app never trusts the model: [parse] validates the shape, rounds and
/// clamps every number to 0–200, and truncates explanations.
class AiSensitivityResponse {
  const AiSensitivityResponse(this.profile, this.explanations);

  final SensitivityProfile profile;
  final Map<Scope, String> explanations;

  static const int maxExplanationLength = 300;

  factory AiSensitivityResponse.parse(String text) {
    final decoded = _decodeObject(text);
    final profile = SensitivityProfile.fromJson(decoded);
    final raw = decoded['explanations'];
    final out = <Scope, String>{};
    if (raw is Map) {
      for (final s in Scope.values) {
        final v = raw[s.jsonKey];
        if (v is String && v.trim().isNotEmpty) {
          final t = v.trim();
          out[s] = t.length > maxExplanationLength
              ? t.substring(0, maxExplanationLength)
              : t;
        }
      }
    }
    return AiSensitivityResponse(profile, Map.unmodifiable(out));
  }
}

Map<String, Object?> _decodeObject(String text) {
  var t = text.trim();
  // Models sometimes wrap JSON in a Markdown fence even when told not to.
  if (t.startsWith('```')) {
    final nl = t.indexOf('\n');
    if (nl != -1) t = t.substring(nl + 1);
    if (t.endsWith('```')) t = t.substring(0, t.length - 3);
    t = t.trim();
  }
  final Object? decoded;
  try {
    decoded = jsonDecode(t);
  } on FormatException catch (e) {
    throw FormatException('AI response is not valid JSON: ${e.message}');
  }
  if (decoded is! Map) {
    throw const FormatException('AI response must be a JSON object');
  }
  return decoded.cast<String, Object?>();
}
