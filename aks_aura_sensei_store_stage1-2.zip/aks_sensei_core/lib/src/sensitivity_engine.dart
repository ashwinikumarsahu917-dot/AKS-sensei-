/// Deterministic, offline sensitivity engine.
///
/// IMPORTANT: this is a transparent heuristic, not a measured truth. There is
/// no official formula for "the right" Free Fire sensitivity. The output is a
/// *recommended starting point*; players are expected to fine-tune it. Every
/// number it produces comes with the reasons that moved it, so the UI can
/// explain itself and the AI stage can fall back to it when offline.
library;

import 'models.dart';

/// One step in the explanation of a value (or a warning).
///
/// [code] is a stable key so the UI can localise the text (English / Hindi);
/// [text] is the English fallback.
class Reason {
  const Reason(this.code, this.text, {this.factor, this.delta});

  final String code;
  final String text;
  final double? factor;
  final double? delta;

  @override
  String toString() => text;
}

/// Player-side inputs (everything that is not hardware).
class PlayerInput {
  const PlayerInput({
    this.style = PlayStyle.balanced,
    this.rank = Rank.gold,
    this.fingers = FingerSetup.threeFinger,
    this.problems = const <Problem>{},
  });

  final PlayStyle style;
  final Rank rank;
  final FingerSetup fingers;
  final Set<Problem> problems;
}

const Map<Scope, double> _kScopeRatio = {
  Scope.general: 1.0,
  Scope.redDot: 0.97,
  Scope.scope2x: 0.92,
  Scope.scope4x: 0.86,
  Scope.awm: 0.72,
  Scope.freeLook: 0.94,
};

// Missing scopes mean "no change" (×1.0).
const Map<PlayStyle, Map<Scope, double>> _kStyle = {
  PlayStyle.drag: {
    Scope.general: 1.06,
    Scope.redDot: 1.05,
    Scope.scope2x: 1.02,
  },
  PlayStyle.brazilianFreestyle: {
    Scope.general: 1.03,
    Scope.redDot: 1.02,
    Scope.freeLook: 1.06,
  },
  PlayStyle.desertEagle: {
    Scope.general: 0.97,
    Scope.redDot: 1.02,
  },
  PlayStyle.ump: {
    Scope.redDot: 0.98,
    Scope.scope2x: 1.02,
  },
  PlayStyle.awm: {
    Scope.general: 0.96,
    Scope.redDot: 0.98,
    Scope.scope4x: 1.04,
    Scope.awm: 1.10,
  },
  PlayStyle.balanced: <Scope, double>{},
};

const Map<FingerSetup, double> _kFinger = {
  FingerSetup.twoFinger: 0.97,
  FingerSetup.threeFinger: 1.0,
  FingerSetup.fourFinger: 1.02,
  FingerSetup.claw: 1.02,
};

const Map<Problem, Map<Scope, double>> _kProblem = {
  Problem.overshoot: {
    Scope.general: 0.92,
    Scope.redDot: 0.92,
    Scope.scope2x: 0.92,
    Scope.scope4x: 0.92,
    Scope.awm: 0.92,
    Scope.freeLook: 0.95,
  },
  Problem.tooSlow: {
    Scope.general: 1.08,
    Scope.redDot: 1.08,
    Scope.scope2x: 1.08,
    Scope.scope4x: 1.08,
    Scope.awm: 1.08,
    Scope.freeLook: 1.05,
  },
  // Jitter is magnified at higher zoom, so zoomed scopes drop more.
  Problem.shaky: {
    Scope.general: 0.97,
    Scope.redDot: 0.96,
    Scope.scope2x: 0.95,
    Scope.scope4x: 0.94,
    Scope.awm: 0.94,
  },
  // Finer vertical control while spraying.
  Problem.recoil: {
    Scope.redDot: 0.96,
    Scope.scope2x: 0.96,
    Scope.scope4x: 0.97,
  },
};

/// All tunable numbers in one place. Stage 3 serves this from the backend
/// (remote config) so tuning never needs an app release.
class EngineConfig {
  const EngineConfig({
    this.baseGeneral = 95,
    this.referenceInches = 6.5,
    this.sizeRangeInches = 1.0,
    this.sizeSwing = 30,
    this.responsivenessSwing = 18,
    this.refreshWeight = 0.30,
    this.touchWeight = 0.30,
    this.tierWeight = 0.25,
    this.ramWeight = 0.15,
    this.scopeRatio = _kScopeRatio,
    this.styleMultiplier = _kStyle,
    this.fingerMultiplier = _kFinger,
    this.problemMultiplier = _kProblem,
    this.rankFloor = 0.96,
    this.rankStep = 0.01,
  });

  static const EngineConfig defaults = EngineConfig();

  /// General value for a 6.5" device of average responsiveness.
  final double baseGeneral;

  /// Screen size that gets no size adjustment; ±[sizeRangeInches] saturates.
  final double referenceInches;
  final double sizeRangeInches;

  /// Max points added/removed for screen size (bigger screen → higher).
  final double sizeSwing;

  /// Max points added/removed for hardware responsiveness
  /// (slower hardware → higher, to compensate for coarse/laggy input).
  final double responsivenessSwing;

  final double refreshWeight;
  final double touchWeight;
  final double tierWeight;
  final double ramWeight;

  final Map<Scope, double> scopeRatio;
  final Map<PlayStyle, Map<Scope, double>> styleMultiplier;
  final Map<FingerSetup, double> fingerMultiplier;
  final Map<Problem, Map<Scope, double>> problemMultiplier;

  /// Rank multiplier = [rankFloor] + [rankStep] × rank.index (Bronze → 0.96,
  /// Grandmaster → 1.02): a deliberately small effect.
  final double rankFloor;
  final double rankStep;
}

/// Result of [SensitivityEngine.recommend].
class SensitivityRecommendation {
  const SensitivityRecommendation({
    required this.profile,
    required this.reasons,
    required this.warnings,
    required this.responsiveness,
  });

  final SensitivityProfile profile;

  /// Ordered explanation for each scope.
  final Map<Scope, List<Reason>> reasons;

  /// Things the user should know (estimated inputs, conflicting problems…).
  final List<Reason> warnings;

  /// 0 (slow hardware) … 1 (very responsive hardware).
  final double responsiveness;

  /// Short English explanation, e.g.
  /// `General 108: 6.5" screen +1; slower hardware +12; Gold ×0.98.`
  String explain(Scope scope) {
    final parts = (reasons[scope] ?? const <Reason>[]).map((r) => r.text);
    return '${scope.label} ${profile[scope]}: ${parts.join('; ')}.';
  }
}

class SensitivityEngine {
  const SensitivityEngine({this.config = EngineConfig.defaults});

  final EngineConfig config;

  /// −1 (small screen) … +1 (large screen), 0 at [EngineConfig.referenceInches].
  double sizeScore(double inches) =>
      ((inches - config.referenceInches) / config.sizeRangeInches)
          .clamp(-1.0, 1.0)
          .toDouble();

  /// 0 … 1 blend of refresh rate, touch sampling, chipset tier and RAM.
  double responsiveness(DeviceSpecs d) {
    final refresh = _norm(d.refreshHz.toDouble(), 60, 144);
    final touch = _norm(d.effectiveTouchSamplingHz.toDouble(), 120, 480);
    final tier = _norm(d.chipsetTier.toDouble(), 1, 5);
    final ram = _norm(d.ramGb, 2, 16);
    final totalWeight = config.refreshWeight +
        config.touchWeight +
        config.tierWeight +
        config.ramWeight;
    return (refresh * config.refreshWeight +
            touch * config.touchWeight +
            tier * config.tierWeight +
            ram * config.ramWeight) /
        totalWeight;
  }

  /// The General value before player-side modifiers are applied.
  double baseGeneral(DeviceSpecs d) =>
      config.baseGeneral +
      sizeScore(d.screenInches) * config.sizeSwing +
      (0.5 - responsiveness(d)) * 2 * config.responsivenessSwing;

  SensitivityRecommendation recommend(
    DeviceSpecs device, [
    PlayerInput input = const PlayerInput(),
  ]) {
    final warnings = <Reason>[];

    final problems = <Problem>{...input.problems};
    if (problems.contains(Problem.overshoot) &&
        problems.contains(Problem.tooSlow)) {
      problems
        ..remove(Problem.overshoot)
        ..remove(Problem.tooSlow);
      warnings.add(const Reason(
        'problems.conflict',
        'Overshooting and "too slow" were both selected, so neither was '
            'applied. Pick the one that matches what you feel most.',
      ));
    }

    final lo = config.referenceInches - config.sizeRangeInches;
    final hi = config.referenceInches + config.sizeRangeInches;
    if (device.screenInches < lo || device.screenInches > hi) {
      warnings.add(Reason(
        'screen.clamped',
        'Screen size is outside the calibrated ${lo.toStringAsFixed(1)}–'
            '${hi.toStringAsFixed(1)}" range, so it was treated as '
            '${device.screenInches < lo ? lo.toStringAsFixed(1) : hi.toStringAsFixed(1)}".',
      ));
    }
    if (device.touchSamplingHz == null) {
      warnings.add(const Reason(
        'touch.estimated',
        'Touch sampling rate is unknown for this device and was estimated '
            'from its chipset tier.',
      ));
    }
    if (!device.dpiAdjustable) {
      warnings.add(const Reason(
        'dpi.fixed',
        'iPhone DPI is fixed (shown as N/A). Sensitivity is tuned by screen '
            'size instead.',
      ));
    }

    final size = sizeScore(device.screenInches);
    final resp = responsiveness(device);
    final sizeDelta = size * config.sizeSwing;
    final hwDelta = (0.5 - resp) * 2 * config.responsivenessSwing;
    final base = config.baseGeneral + sizeDelta + hwDelta;

    final values = <Scope, double>{};
    final reasons = <Scope, List<Reason>>{};

    for (final scope in Scope.values) {
      final list = <Reason>[];
      var v = base;

      if (scope == Scope.general) {
        if (sizeDelta.abs() >= 0.5) {
          list.add(Reason(
            'screen',
            '${device.screenInches.toStringAsFixed(1)}" screen '
                '${_signed(sizeDelta)}',
            delta: sizeDelta,
          ));
        }
        if (hwDelta.abs() >= 0.5) {
          list.add(Reason(
            hwDelta > 0 ? 'hardware.slow' : 'hardware.fast',
            '${hwDelta > 0 ? 'slower' : 'faster'} hardware ${_signed(hwDelta)}',
            delta: hwDelta,
          ));
        }
      } else {
        final ratio = config.scopeRatio[scope] ?? 1.0;
        v *= ratio;
        list.add(Reason(
          'scope_ratio',
          'starts from General ${_fmtMul(ratio)}',
          factor: ratio,
        ));
      }

      void mul(String code, String label, double f) {
        if ((f - 1.0).abs() < 1e-9) return;
        v *= f;
        list.add(Reason(code, '$label ${_fmtMul(f)}', factor: f));
      }

      mul('style', input.style.label,
          config.styleMultiplier[input.style]?[scope] ?? 1.0);
      mul('fingers', input.fingers.label,
          config.fingerMultiplier[input.fingers] ?? 1.0);
      mul('rank', input.rank.label,
          config.rankFloor + config.rankStep * input.rank.index);
      for (final p in Problem.values) {
        if (!problems.contains(p)) continue;
        mul('problem.${p.name}', p.label,
            config.problemMultiplier[p]?[scope] ?? 1.0);
      }

      if (v < kSensitivityMin || v > kSensitivityMax) {
        list.add(const Reason(
          'clamped',
          'limited to the 0–200 range',
        ));
      }

      values[scope] = v;
      reasons[scope] = List.unmodifiable(list);
    }

    final profile = SensitivityProfile(
      general: values[Scope.general]!,
      redDot: values[Scope.redDot]!,
      scope2x: values[Scope.scope2x]!,
      scope4x: values[Scope.scope4x]!,
      awm: values[Scope.awm]!,
      freeLook: values[Scope.freeLook]!,
    );

    return SensitivityRecommendation(
      profile: profile,
      reasons: Map.unmodifiable(reasons),
      warnings: List.unmodifiable(warnings),
      responsiveness: resp,
    );
  }
}

double _norm(double v, double lo, double hi) =>
    ((v - lo) / (hi - lo)).clamp(0.0, 1.0).toDouble();

String _signed(double d) => '${d >= 0 ? '+' : '-'}${d.abs().round()}';

String _fmtMul(double f) => '×${f.toStringAsFixed(2)}';
