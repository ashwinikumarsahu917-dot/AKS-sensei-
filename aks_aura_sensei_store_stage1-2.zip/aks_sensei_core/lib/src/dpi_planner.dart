/// Helps the user change Android display density *manually*.
///
/// An app cannot change DPI silently on Android. The only routes are the
/// user's own Developer options → "Smallest width" or `adb shell wm density`.
/// This class only does the arithmetic and wording inputs; it changes nothing.
library;

import 'dart:math' as math;

class DpiPlanner {
  const DpiPlanner({required this.nativeDpi, required this.smallestSidePx});

  /// Density the phone is using right now (`DisplayMetrics.densityDpi`).
  final int nativeDpi;

  /// Smaller of the screen's width/height in physical pixels.
  final int smallestSidePx;

  /// Android's Developer options will not accept a smallest width below this.
  static const int minSmallestWidthDp = 320;

  static const String adbReset = 'adb shell wm density reset';

  /// Lowest suggested DPI (about 30% below the current one).
  int get minDpi => math.max(120, (nativeDpi * 0.7).round());

  /// Highest suggested DPI: about 30% above the current one, but never so high
  /// that the smallest width would fall under [minSmallestWidthDp].
  int get maxDpi {
    final byWidthFloor = (smallestSidePx * 160 / minSmallestWidthDp).floor();
    final byRatio = (nativeDpi * 1.3).round();
    return math.max(nativeDpi, math.min(byRatio, byWidthFloor));
  }

  int clampDpi(int dpi) => dpi.clamp(minDpi, maxDpi).toInt();

  /// The "Smallest width" value (dp) that corresponds to [dpi].
  int smallestWidthDp(int dpi) => (smallestSidePx * 160 / dpi).round();

  /// Quick-pick values: the current DPI plus every 40 dpi inside the range.
  List<int> get presets {
    final out = <int>{nativeDpi};
    var v = ((minDpi + 19) ~/ 20) * 20;
    while (v <= maxDpi) {
      out.add(v);
      v += 40;
    }
    return out.toList()..sort();
  }

  String adbCommand(int dpi) => 'adb shell wm density $dpi';
}
