import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:test/test.dart';

void main() {
  group('DpiPlanner', () {
    // Redmi 9 class: 720 px wide, 320 dpi.
    const low = DpiPlanner(nativeDpi: 320, smallestSidePx: 720);
    // 1080 px wide at 440 dpi.
    const fhd = DpiPlanner(nativeDpi: 440, smallestSidePx: 1080);

    test('range is about +/-30% but never below 320dp smallest width', () {
      expect(low.minDpi, 224);
      expect(low.maxDpi, 360); // 720px / 2 -> exactly 320dp
      expect(fhd.minDpi, 308);
      expect(fhd.maxDpi, 540); // capped by the 320dp floor, not 572
    });

    test('smallest width maths', () {
      expect(low.smallestWidthDp(320), 360);
      expect(low.smallestWidthDp(low.maxDpi), 320);
      expect(fhd.smallestWidthDp(440), 393);
      expect(fhd.smallestWidthDp(fhd.maxDpi), 320);
    });

    test('presets include the current DPI, are sorted and in range', () {
      expect(low.presets, [240, 280, 320, 360]);
      for (final p in [low, fhd]) {
        final list = p.presets;
        expect(list, contains(p.nativeDpi));
        expect([...list]..sort(), list);
        for (final v in list) {
          expect(v, inInclusiveRange(p.minDpi, p.maxDpi));
        }
      }
    });

    test('clampDpi keeps values inside the range', () {
      expect(low.clampDpi(100), 224);
      expect(low.clampDpi(999), 360);
      expect(low.clampDpi(300), 300);
    });

    test('the current DPI is always allowed, even on odd screens', () {
      // Tiny smallest side: the 320dp rule alone would forbid the native DPI.
      const odd = DpiPlanner(nativeDpi: 480, smallestSidePx: 480);
      expect(odd.maxDpi, 480);
      expect(odd.presets, contains(480));
    });

    test('ADB commands', () {
      expect(low.adbCommand(280), 'adb shell wm density 280');
      expect(DpiPlanner.adbReset, 'adb shell wm density reset');
    });
  });

  group('SensitivityProfile.withScope', () {
    test('replaces exactly one scope and clamps', () {
      final p = SensitivityProfile(
          general: 100, redDot: 90, scope2x: 80, scope4x: 70, awm: 60, freeLook: 50);
      final q = p.withScope(Scope.awm, 250);
      expect(q.awm, 200);
      expect(q.general, 100);
      expect(q.freeLook, 50);
      expect(p.withScope(Scope.redDot, -3).redDot, 0);
      for (final s in Scope.values) {
        expect(p.withScope(s, 77)[s], 77);
      }
    });
  });
}
