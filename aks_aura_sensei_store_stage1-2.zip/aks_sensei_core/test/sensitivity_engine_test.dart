import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:test/test.dart';

DeviceSpecs dev({
  double inches = 6.5,
  int hz = 60,
  double ram = 4,
  int tier = 3,
  int? touch,
  DevicePlatform platform = DevicePlatform.android,
}) =>
    DeviceSpecs(
      screenInches: inches,
      refreshHz: hz,
      ramGb: ram,
      chipsetTier: tier,
      touchSamplingHz: touch,
      platform: platform,
    );

void main() {
  const engine = SensitivityEngine();

  group('clampSensitivity', () {
    test('clamps to 0..200 and rounds', () {
      expect(clampSensitivity(-5), 0);
      expect(clampSensitivity(0), 0);
      expect(clampSensitivity(99.4), 99);
      expect(clampSensitivity(99.5), 100);
      expect(clampSensitivity(200), 200);
      expect(clampSensitivity(250), 200);
      expect(clampSensitivity(1e30), 200);
      expect(clampSensitivity(-1e30), 0);
    });

    test('rejects NaN and infinity', () {
      expect(() => clampSensitivity(double.nan), throwsArgumentError);
      expect(() => clampSensitivity(double.infinity), throwsArgumentError);
    });

    test('SensitivityProfile clamps every field', () {
      final p = SensitivityProfile(
        general: 500,
        redDot: -20,
        scope2x: 100.6,
        scope4x: 0,
        awm: 200,
        freeLook: 150,
      );
      expect(p.general, 200);
      expect(p.redDot, 0);
      expect(p.scope2x, 101);
      expect(p.scope4x, 0);
      expect(p.awm, 200);
      expect(p.freeLook, 150);
    });
  });

  group('engine: hardware', () {
    test('bigger screen -> higher General', () {
      final small = engine.recommend(dev(inches: 5.8)).profile.general;
      final large = engine.recommend(dev(inches: 7.0)).profile.general;
      expect(large, greaterThan(small + 20));
    });

    test('faster hardware -> lower General (same screen)', () {
      final weak = engine
          .recommend(dev(hz: 60, ram: 2, tier: 1, touch: 120))
          .profile
          .general;
      final strong = engine
          .recommend(dev(hz: 144, ram: 12, tier: 5, touch: 480))
          .profile
          .general;
      expect(weak, greaterThan(strong + 20));
    });

    test('responsiveness is within 0..1 and monotonic in refresh rate', () {
      final a = engine.responsiveness(dev(hz: 60));
      final b = engine.responsiveness(dev(hz: 120));
      final c = engine.responsiveness(dev(hz: 240));
      expect(a, inInclusiveRange(0, 1));
      expect(c, inInclusiveRange(0, 1));
      expect(b, greaterThan(a));
      expect(c, greaterThanOrEqualTo(b));
    });

    test('unknown touch rate is estimated and flagged', () {
      final r = engine.recommend(dev());
      expect(r.warnings.map((w) => w.code), contains('touch.estimated'));
      final known = engine.recommend(dev(touch: 240));
      expect(known.warnings.map((w) => w.code),
          isNot(contains('touch.estimated')));
    });

    test('iOS: DPI is fixed, touch rate estimated from refresh rate', () {
      final ios = dev(platform: DevicePlatform.ios, hz: 120);
      expect(ios.dpiAdjustable, isFalse);
      expect(ios.effectiveTouchSamplingHz, 240);
      expect(dev(platform: DevicePlatform.ios, hz: 60).effectiveTouchSamplingHz,
          120);
      final r = engine.recommend(ios);
      expect(r.warnings.map((w) => w.code), contains('dpi.fixed'));
      expect(dev().dpiAdjustable, isTrue);
    });

    test('screen far outside the range is flagged, not extrapolated', () {
      final tablet = engine.recommend(dev(inches: 10.0));
      final edge = engine.recommend(dev(inches: 7.5));
      expect(tablet.profile.general, edge.profile.general);
      expect(tablet.warnings.map((w) => w.code), contains('screen.clamped'));
    });
  });

  group('engine: player input', () {
    final device = dev(inches: 6.5, hz: 90, ram: 6, tier: 3, touch: 240);
    final baseline = engine.recommend(device).profile;

    test('scopes are ordered General > Red Dot > 2x > 4x > AWM', () {
      expect(baseline.general, greaterThan(baseline.redDot));
      expect(baseline.redDot, greaterThan(baseline.scope2x));
      expect(baseline.scope2x, greaterThan(baseline.scope4x));
      expect(baseline.scope4x, greaterThan(baseline.awm));
    });

    test('overshoot lowers every value, too slow raises every value', () {
      final over = engine
          .recommend(device, const PlayerInput(problems: {Problem.overshoot}))
          .profile;
      final slow = engine
          .recommend(device, const PlayerInput(problems: {Problem.tooSlow}))
          .profile;
      for (final s in Scope.values) {
        expect(over[s], lessThan(baseline[s]), reason: s.label);
        expect(slow[s], greaterThan(baseline[s]), reason: s.label);
      }
    });

    test('overshoot + too slow cancel out with a warning', () {
      final r = engine.recommend(
        device,
        const PlayerInput(problems: {Problem.overshoot, Problem.tooSlow}),
      );
      expect(r.profile, baseline);
      expect(r.warnings.map((w) => w.code), contains('problems.conflict'));
    });

    test('shaky lowers zoomed scopes more than General', () {
      final p = engine
          .recommend(device, const PlayerInput(problems: {Problem.shaky}))
          .profile;
      final dGeneral = baseline.general - p.general;
      final dAwm = baseline.awm - p.awm;
      expect(dGeneral, greaterThan(0));
      expect(dAwm, greaterThan(0));
      expect(p.scope4x / baseline.scope4x,
          lessThan(p.general / baseline.general));
    });

    test('style modifiers move the expected scopes', () {
      final drag = engine
          .recommend(device, const PlayerInput(style: PlayStyle.drag))
          .profile;
      final awm = engine
          .recommend(device, const PlayerInput(style: PlayStyle.awm))
          .profile;
      expect(drag.general, greaterThan(baseline.general));
      expect(drag.redDot, greaterThan(baseline.redDot));
      expect(awm.awm, greaterThan(baseline.awm));
      expect(awm.general, lessThan(baseline.general));
    });

    test('finger setup and rank have small, ordered effects', () {
      int general(PlayerInput i) => engine.recommend(device, i).profile.general;
      expect(general(const PlayerInput(fingers: FingerSetup.fourFinger)),
          greaterThan(general(const PlayerInput(fingers: FingerSetup.twoFinger))));
      expect(general(const PlayerInput(rank: Rank.grandmaster)),
          greaterThan(general(const PlayerInput(rank: Rank.bronze))));
      // "Small": the whole rank range stays within ~8% of the baseline.
      final spread = general(const PlayerInput(rank: Rank.grandmaster)) -
          general(const PlayerInput(rank: Rank.bronze));
      expect(spread, lessThan(baseline.general * 0.08 + 1));
    });

    test('same input always gives the same output', () {
      const input = PlayerInput(
        style: PlayStyle.drag,
        problems: {Problem.shaky, Problem.recoil},
      );
      expect(engine.recommend(device, input).profile,
          engine.recommend(device, input).profile);
    });
  });

  group('engine: bounds', () {
    test('every value stays within 0..200 across a wide input grid', () {
      var checked = 0;
      for (final inches in [3.5, 5.5, 6.5, 7.5, 10.0]) {
        for (final tier in [1, 3, 5]) {
          for (final hz in [60, 120, 165]) {
            final d = dev(inches: inches, tier: tier, hz: hz, ram: tier * 3.0);
            for (final style in PlayStyle.values) {
              for (final fingers in FingerSetup.values) {
                for (final rank in [Rank.bronze, Rank.gold, Rank.grandmaster]) {
                  for (var mask = 0; mask < 16; mask++) {
                    final problems = <Problem>{
                      for (final p in Problem.values)
                        if (mask & (1 << p.index) != 0) p,
                    };
                    final r = engine.recommend(
                      d,
                      PlayerInput(
                        style: style,
                        fingers: fingers,
                        rank: rank,
                        problems: problems,
                      ),
                    );
                    for (final s in Scope.values) {
                      expect(r.profile[s], inInclusiveRange(0, 200));
                    }
                    checked++;
                  }
                }
              }
            }
          }
        }
      }
      expect(checked, 5 * 3 * 3 * 6 * 4 * 3 * 16);
    });

    test('a hostile config cannot escape the 0..200 range', () {
      const wild = SensitivityEngine(config: EngineConfig(baseGeneral: 900));
      final r = wild.recommend(dev());
      for (final s in Scope.values) {
        expect(r.profile[s], inInclusiveRange(0, 200));
      }
      expect(r.profile.general, 200);
      expect(r.reasons[Scope.general]!.map((x) => x.code), contains('clamped'));

      const negative = SensitivityEngine(config: EngineConfig(baseGeneral: -900));
      expect(negative.recommend(dev()).profile.general, 0);
    });
  });

  group('engine: explanations', () {
    test('every scope has reasons and a readable sentence', () {
      final r = engine.recommend(
        dev(inches: 6.8, hz: 120, ram: 8, tier: 5, touch: 240),
        const PlayerInput(
          style: PlayStyle.drag,
          problems: {Problem.overshoot},
        ),
      );
      for (final s in Scope.values) {
        expect(r.reasons[s], isNotEmpty);
        final text = r.explain(s);
        expect(text, startsWith('${s.label} ${r.profile[s]}:'));
        expect(text, contains('Overshooting'));
      }
      // Drag only modifies General, Red Dot and 2x, so it is only explained there.
      for (final s in [Scope.general, Scope.redDot, Scope.scope2x]) {
        expect(r.explain(s), contains('Drag'));
      }
      expect(r.explain(Scope.awm), isNot(contains('Drag')));
    });

    test('golden values for two reference devices (±1 for rounding)', () {
      // Redmi 9 class: 6.53", 60 Hz, 4 GB, tier 2, touch unknown.
      final low = engine
          .recommend(dev(inches: 6.53, hz: 60, ram: 4, tier: 2))
          .profile;
      // S24 Ultra class: 6.8", 120 Hz, 12 GB, tier 5, 240 Hz touch.
      final high = engine
          .recommend(dev(inches: 6.8, hz: 120, ram: 12, tier: 5, touch: 240))
          .profile;
      expect(low.general, closeTo(106, 1));
      expect(high.general, closeTo(96, 1));
      expect(low.general, greaterThan(high.general));
    });
  });

  group('AiSensitivityResponse.parse', () {
    const valid = '''
{"general":100,"red_dot":96,"scope_2x":92,"scope_4x":86,"awm":72,
 "free_look":94,
 "explanations":{"general":"Bigger screen needs more travel.","awm":"  "}}''';

    test('accepts valid JSON and keeps non-empty explanations', () {
      final r = AiSensitivityResponse.parse(valid);
      expect(r.profile.general, 100);
      expect(r.profile.freeLook, 94);
      expect(r.explanations[Scope.general], contains('Bigger screen'));
      expect(r.explanations.containsKey(Scope.awm), isFalse);
    });

    test('rounds and clamps out-of-range numbers', () {
      final r = AiSensitivityResponse.parse(
        '{"general":350,"red_dot":-10,"scope_2x":99.5,"scope_4x":0,'
        '"awm":200.4,"free_look":1e9}',
      );
      expect(r.profile.general, 200);
      expect(r.profile.redDot, 0);
      expect(r.profile.scope2x, 100);
      expect(r.profile.awm, 200);
      expect(r.profile.freeLook, 200);
    });

    test('tolerates a Markdown fence around the JSON', () {
      final r = AiSensitivityResponse.parse('```json\n$valid\n```');
      expect(r.profile.redDot, 96);
    });

    test('rejects missing keys, strings, null and non-objects', () {
      expect(() => AiSensitivityResponse.parse('{"general":100}'),
          throwsFormatException);
      expect(
          () => AiSensitivityResponse.parse(
              '{"general":"100","red_dot":1,"scope_2x":1,"scope_4x":1,'
              '"awm":1,"free_look":1}'),
          throwsFormatException);
      expect(
          () => AiSensitivityResponse.parse(
              '{"general":null,"red_dot":1,"scope_2x":1,"scope_4x":1,'
              '"awm":1,"free_look":1}'),
          throwsFormatException);
      expect(() => AiSensitivityResponse.parse('[1,2,3]'), throwsFormatException);
      expect(() => AiSensitivityResponse.parse('not json'), throwsFormatException);
      expect(() => AiSensitivityResponse.parse(''), throwsFormatException);
    });

    test('truncates very long explanations', () {
      final long = 'x' * 1000;
      final r = AiSensitivityResponse.parse(
        '{"general":1,"red_dot":1,"scope_2x":1,"scope_4x":1,"awm":1,'
        '"free_look":1,"explanations":{"general":"$long"}}',
      );
      expect(r.explanations[Scope.general]!.length,
          AiSensitivityResponse.maxExplanationLength);
    });

    test('toJson round-trips through fromJson', () {
      final p = engine.recommend(dev()).profile;
      expect(SensitivityProfile.fromJson(p.toJson()), p);
    });
  });
}
