import 'dart:io';

import 'package:aks_sensei_core/aks_sensei_core.dart';
import 'package:test/test.dart';

/// Brands / series the product spec requires in the manual selector.
const requiredSeries = <String, List<String>>{
  'samsung': [
    'galaxy-s', 'galaxy-z-fold', 'galaxy-z-flip', 'galaxy-a', 'galaxy-m',
    'galaxy-f', 'galaxy-xcover',
  ],
  'xiaomi': ['xiaomi-numbered', 'xiaomi-t', 'xiaomi-civi', 'xiaomi-mix'],
  'redmi': [
    'redmi-note', 'redmi-numbered', 'redmi-a', 'redmi-k', 'redmi-turbo',
  ],
  'poco': ['poco-f', 'poco-x', 'poco-m', 'poco-c'],
  'google-pixel': ['pixel', 'pixel-pro', 'pixel-a', 'pixel-fold'],
  'oneplus': [
    'oneplus-flagship', 'oneplus-r', 'oneplus-nord', 'oneplus-open',
  ],
  'motorola': ['moto-edge', 'moto-g', 'moto-e', 'moto-razr'],
  'nothing': ['nothing-phone'],
  'cmf': ['cmf-phone'],
  'oppo': ['oppo-find-x', 'oppo-find-n', 'oppo-reno', 'oppo-a', 'oppo-k'],
  'vivo': ['vivo-x', 'vivo-v', 'vivo-y', 'vivo-t', 'vivo-s'],
  'iqoo': ['iqoo-numbered', 'iqoo-neo', 'iqoo-z'],
  'realme': [
    'realme-gt', 'realme-number', 'realme-p', 'realme-narzo', 'realme-c',
  ],
  'tecno': [
    'tecno-phantom', 'tecno-camon', 'tecno-spark', 'tecno-pova', 'tecno-pop',
  ],
  'infinix': [
    'infinix-zero', 'infinix-note', 'infinix-hot', 'infinix-smart',
    'infinix-gt',
  ],
  'itel': ['itel-a', 'itel-p', 'itel-s'],
  'asus': ['asus-zenfone', 'asus-rog-phone'],
  'sony': ['xperia-1', 'xperia-5', 'xperia-10'],
  'honor': [
    'honor-magic', 'honor-magic-v', 'honor-number', 'honor-x', 'honor-play',
  ],
  'huawei': [
    'huawei-mate', 'huawei-mate-x', 'huawei-pura', 'huawei-nova',
    'huawei-enjoy',
  ],
  'nokia-hmd': ['nokia', 'hmd'],
  'lenovo-legion': ['legion-phone', 'legion-y'],
  'zte-nubia-redmagic': [
    'redmagic', 'nubia-z', 'nubia-neo', 'zte-blade', 'zte-axon',
  ],
  'tcl': ['tcl-numbered', 'tcl-nxtpaper'],
  'alcatel': ['alcatel-1', 'alcatel-3', 'alcatel-v'],
  'lava': ['lava-blaze', 'lava-agni', 'lava-yuva', 'lava-storm'],
  'micromax': ['micromax-in', 'micromax-canvas'],
  'sharp': ['aquos-r', 'aquos-sense', 'aquos-wish', 'aquos-zero'],
  'kyocera': ['kyocera-torque', 'kyocera-duraforce'],
  'fairphone': ['fairphone'],
  'cat': ['cat-s'],
  'crosscall': ['crosscall-core'],
  'ulefone': ['ulefone-armor'],
  'blackview': ['blackview-bv'],
  'doogee': ['doogee-s'],
  'oukitel': ['oukitel-wp'],
  'umidigi': ['umidigi-bison'],
  'blu': ['blu-g', 'blu-view', 'blu-bold'],
  'meizu': ['meizu-numbered', 'meizu-note'],
  'lg': ['lg-v', 'lg-g', 'lg-wing-velvet', 'lg-k-q'],
  'htc': ['htc-u', 'htc-desire', 'htc-wildfire'],
  'blackberry': ['blackberry-key', 'blackberry-priv'],
  'wiko': ['wiko-view', 'wiko-power', 'wiko-t'],
  'walton': ['walton-primo'],
  'apple': [
    'iphone-classic', 'iphone-5', 'iphone-6', 'iphone-7', 'iphone-8-x',
    'iphone-xr-xs', 'iphone-11', 'iphone-se', 'iphone-12', 'iphone-13',
    'iphone-14', 'iphone-15', 'iphone-16', 'iphone-17', 'iphone-18',
  ],
};

/// Every iPhone from the original through the 17 series, plus the confirmed
/// 18 Pro. (The base iPhone 18 is intentionally absent until published.)
const iphones = <String>[
  'iPhone', 'iPhone 3G', 'iPhone 3GS', 'iPhone 4', 'iPhone 4S', 'iPhone 5',
  'iPhone 5C', 'iPhone 5S', 'iPhone SE (1st generation)', 'iPhone 6',
  'iPhone 6 Plus', 'iPhone 6S', 'iPhone 6S Plus', 'iPhone 7',
  'iPhone 7 Plus', 'iPhone 8', 'iPhone 8 Plus', 'iPhone X', 'iPhone XR',
  'iPhone XS', 'iPhone XS Max', 'iPhone 11', 'iPhone 11 Pro',
  'iPhone 11 Pro Max', 'iPhone SE (2nd generation)', 'iPhone 12 mini',
  'iPhone 12', 'iPhone 12 Pro', 'iPhone 12 Pro Max', 'iPhone 13 mini',
  'iPhone 13', 'iPhone 13 Pro', 'iPhone 13 Pro Max',
  'iPhone SE (3rd generation)', 'iPhone 14', 'iPhone 14 Plus',
  'iPhone 14 Pro', 'iPhone 14 Pro Max', 'iPhone 15', 'iPhone 15 Plus',
  'iPhone 15 Pro', 'iPhone 15 Pro Max', 'iPhone 16e', 'iPhone 16',
  'iPhone 16 Plus', 'iPhone 16 Pro', 'iPhone 16 Pro Max', 'iPhone 17',
  'iPhone Air', 'iPhone 17 Pro', 'iPhone 17 Pro Max', 'iPhone 18 Pro',
];

Map<String, Object?> doc(List<Object?> brands) =>
    {'schema': 1, 'version': 't', 'brands': brands};

Map<String, Object?> brand(String id, List<Object?> series,
        {String platform = 'android'}) =>
    {'id': id, 'name': id, 'platform': platform, 'series': series};

Map<String, Object?> series(String id,
        {double inches = 6.5, List<Object?>? models}) =>
    {
      'id': id,
      'name': id,
      'in': inches,
      'hz': 60,
      'ram': 4,
      'tier': 3,
      if (models != null) 'models': models,
    };

void main() {
  late DeviceDatabase db;

  setUpAll(() {
    // `dart test` runs from the package root.
    db = DeviceDatabase.parse(File('assets/devices.json').readAsStringSync());
  });

  group('seed database', () {
    test('is healthy: validate() reports nothing', () {
      expect(db.validate(), isEmpty);
    });

    test('has the size and shape we expect', () {
      expect(db.schema, 1);
      expect(db.version, isNotEmpty);
      expect(db.brands.length, greaterThanOrEqualTo(45));
      expect(db.allSeries.length, greaterThanOrEqualTo(140));
      expect(db.allModels.length, greaterThanOrEqualTo(200));
    });

    test('covers every required brand and series', () {
      for (final entry in requiredSeries.entries) {
        final b = db.brand(entry.key);
        expect(b, isNotNull, reason: 'missing brand ${entry.key}');
        final have = b!.series.map((s) => s.id).toSet();
        for (final sid in entry.value) {
          expect(have, contains(sid), reason: '${entry.key} lacks $sid');
        }
      }
    });

    test('has every iPhone from the original to the 17 series (+18 Pro)', () {
      for (final name in iphones) {
        final m = db.findByName(name);
        expect(m, isNotNull, reason: 'missing $name');
        expect(m!.brandId, 'apple');
      }
    });

    test('iPhones are iOS: DPI is not adjustable', () {
      final apple = db.brand('apple')!;
      expect(apple.platform, DevicePlatform.ios);
      for (final s in apple.series) {
        for (final m in s.models) {
          expect(m.specs.platform, DevicePlatform.ios, reason: m.name);
          expect(m.specs.dpiAdjustable, isFalse, reason: m.name);
        }
      }
    });

    test('every non-Apple brand is Android and DPI-adjustable', () {
      for (final b in db.brands.where((b) => b.id != 'apple')) {
        expect(b.platform, DevicePlatform.android, reason: b.id);
        for (final s in b.series) {
          expect(s.specs.dpiAdjustable, isTrue, reason: s.id);
        }
      }
    });

    test('models inherit and override series values', () {
      final s24u = db.findByName('Galaxy S24 Ultra')!;
      expect(s24u.specs.refreshHz, 120); // inherited
      expect(s24u.specs.touchSamplingHz, 240); // inherited
      expect(s24u.specs.screenInches, 6.8); // overridden
      expect(s24u.specs.ramGb, 12); // overridden
      expect(s24u.specs.chipsetTier, 5);
      expect(db.findByName('ROG Phone 8 Pro')!.specs.touchSamplingHz, 720);
    });
  });

  group('lookups', () {
    test('findByCode: Samsung model code, case/space-insensitive', () {
      expect(db.findByCode('SM-S928B')!.name, 'Galaxy S24 Ultra');
      expect(db.findByCode(' sm-s928b ')!.name, 'Galaxy S24 Ultra');
      expect(db.findByCode('SM-S928Z'), isNull);
    });

    test('findByCode: iOS identifiers are not confused with names', () {
      expect(db.findByCode('iPhone17,3')!.name, 'iPhone 16');
      expect(db.findByCode('iPhone14,5')!.name, 'iPhone 13');
      expect(db.findByCode('iPhone1,1')!.name, 'iPhone');
      expect(db.findByCode('iPhone19,2')!.name, 'iPhone 18 Pro');
      expect(db.findByCode('iPhone 11'), isNull);
    });

    test('findByCode: Pixel reports its marketing name as Build.MODEL', () {
      expect(db.findByCode('Pixel 8 Pro')!.name, 'Pixel 8 Pro');
    });

    test('"+" models are distinct from their base model', () {
      expect(db.findByName('Galaxy S24+')!.name, 'Galaxy S24+');
      expect(db.findByName('Galaxy S24')!.name, 'Galaxy S24');
      expect(db.findByCode('SM-S926B')!.name, 'Galaxy S24+');
      expect(db.findByCode('SM-S921B')!.name, 'Galaxy S24');
    });

    test('findByName ignores a leading brand but is not fuzzy', () {
      expect(db.findByName('Samsung Galaxy S24 Ultra')!.name,
          'Galaxy S24 Ultra');
      expect(db.findByName('galaxy s24')!.name, 'Galaxy S24');
      expect(db.findByName('Xiaomi Redmi Note 13 Pro')!.name,
          'Redmi Note 13 Pro');
      expect(db.findByName('Google Pixel 8')!.name, 'Pixel 8');
      expect(db.findByName('Apple iPhone 15')!.name, 'iPhone 15');
      expect(db.findByName('Galaxy S24 FE'), isNull);
      expect(db.findByName(''), isNull);
    });

    test('searchModels finds by prefix then substring', () {
      final hits = db.searchModels('redmi note 13');
      expect(hits, isNotEmpty);
      expect(hits.every((m) => m.name.contains('Redmi Note 13')), isTrue);
      final sub = db.searchModels('s24 ultra');
      expect(sub.map((m) => m.name), contains('Galaxy S24 Ultra'));
      expect(db.searchModels('   '), isEmpty);
      expect(db.searchModels('galaxy', limit: 3).length, 3);
    });
  });

  group('resolve (auto-detect)', () {
    test('exact code: DB supplies tier/touch/screen, OS supplies RAM/Hz', () {
      final r = db.resolve(const DetectedDevice(
        modelCode: 'SM-S928B',
        ramGb: 11.2, // OS-reported usable RAM of a 12 GB phone
        maxRefreshHz: 120,
        dpi: 480,
      ));
      expect(r.level, MatchLevel.exactCode);
      expect(r.isApproximate, isFalse);
      expect(r.specs.ramGb, 12);
      expect(r.specs.screenInches, 6.8);
      expect(r.specs.chipsetTier, 5);
      expect(r.specs.touchSamplingHz, 240);
      expect(r.specs.dpi, 480);
    });

    test('falls back to marketing name when the code is unknown', () {
      final r = db.resolve(const DetectedDevice(
        modelCode: '23123RN',
        marketingName: 'Redmi Note 13 Pro',
      ));
      expect(r.level, MatchLevel.exactName);
      expect(r.model!.name, 'Redmi Note 13 Pro');
    });

    test('RAM variants: measured RAM wins over the DB value', () {
      final r = db.resolve(const DetectedDevice(
        modelCode: 'M2004J19G',
        ramGb: 2.8,
      ));
      expect(r.model!.name, 'Redmi 9');
      expect(r.specs.ramGb, 3);
    });

    test('unknown Android device: measured values + RAM-based tier', () {
      final r = db.resolve(const DetectedDevice(
        modelCode: 'XYZ-1',
        screenInches: 6.1,
        maxRefreshHz: 90,
        ramGb: 5.4,
      ));
      expect(r.level, MatchLevel.genericFallback);
      expect(r.isApproximate, isTrue);
      expect(r.model, isNull);
      expect(r.specs.screenInches, 6.1);
      expect(r.specs.refreshHz, 90);
      expect(r.specs.ramGb, 6);
      expect(r.specs.chipsetTier, 3);
      expect(r.specs.touchSamplingHz, isNull);
      expect(r.notes, isNotEmpty);
    });

    test('totally empty detection still yields usable specs', () {
      final r = db.resolve(const DetectedDevice());
      expect(r.level, MatchLevel.genericFallback);
      expect(r.specs.screenInches, 6.5);
      expect(r.specs.refreshHz, 60);
    });

    test('iPhone: resolved by identifier, DPI N/A', () {
      final r = db.resolve(const DetectedDevice(
        platform: DevicePlatform.ios,
        modelCode: 'iPhone17,1',
      ));
      expect(r.model!.name, 'iPhone 16 Pro');
      expect(r.specs.refreshHz, 120);
      expect(r.specs.dpiAdjustable, isFalse);
    });

    test('unknown future iPhone is treated as flagship-tier', () {
      final r = db.resolve(const DetectedDevice(
        platform: DevicePlatform.ios,
        modelCode: 'iPhone99,1',
        ramGb: 12,
        screenInches: 6.3,
        maxRefreshHz: 120,
      ));
      expect(r.level, MatchLevel.genericFallback);
      expect(r.specs.chipsetTier, 5);
      expect(r.specs.dpiAdjustable, isFalse);
    });

    test('unverified models carry a note', () {
      final r = db.resolve(const DetectedDevice(
        platform: DevicePlatform.ios,
        marketingName: 'iPhone 18 Pro Max',
      ));
      expect(r.model!.unverified, isTrue);
      expect(r.notes, isNotEmpty);
    });
  });

  group('manual selection (Brand -> Series -> Model)', () {
    test('series only: typical values, flagged approximate', () {
      final r = db.specsFromSelection(brandId: 'poco', seriesId: 'poco-f');
      expect(r.level, MatchLevel.seriesDefaults);
      expect(r.isApproximate, isTrue);
      expect(r.specs.screenInches, 6.67);
      expect(r.specs.chipsetTier, 4);
    });

    test('with a model: exact specs', () {
      final r = db.specsFromSelection(
        brandId: 'poco',
        seriesId: 'poco-f',
        modelId: 'poco-f6-pro',
        dpi: 440,
      );
      expect(r.level, MatchLevel.manualModel);
      expect(r.isApproximate, isFalse);
      expect(r.specs.ramGb, 12);
      expect(r.specs.chipsetTier, 5);
      expect(r.specs.dpi, 440);
    });

    test('unknown ids throw', () {
      expect(() => db.specsFromSelection(brandId: 'nope', seriesId: 'x'),
          throwsArgumentError);
      expect(
          () => db.specsFromSelection(
              brandId: 'poco', seriesId: 'poco-f', modelId: 'nope'),
          throwsArgumentError);
    });
  });

  group('helpers', () {
    test('roundRamToMarketed snaps OS-reported RAM to marketed sizes', () {
      expect(roundRamToMarketed(7.4), 8);
      expect(roundRamToMarketed(11.2), 12);
      expect(roundRamToMarketed(3.7), 4);
      expect(roundRamToMarketed(15.4), 16);
      expect(roundRamToMarketed(4.0), 4);
      expect(roundRamToMarketed(5.6), 6);
      expect(roundRamToMarketed(1.9), 2);
      expect(roundRamToMarketed(30), 24);
    });

    test('estimateTierFromRam', () {
      expect(estimateTierFromRam(2), 1);
      expect(estimateTierFromRam(4), 2);
      expect(estimateTierFromRam(6), 3);
      expect(estimateTierFromRam(8), 4);
      expect(estimateTierFromRam(12), 5);
    });

    test('normalizers keep names loose and codes strict', () {
      expect(normalizeName('Redmi Note 13 Pro+'), 'redminote13proplus');
      expect(normalizeName('Galaxy S24+'), isNot(normalizeName('Galaxy S24')));
      expect(normalizeCode(' iPhone 1,1 '), 'IPHONE1,1');
      expect(normalizeCode('iPhone1,1'), isNot(normalizeCode('iPhone11')));
    });
  });

  group('parsing and validation of remote updates', () {
    test('rejects invalid JSON and wrong shapes', () {
      expect(() => DeviceDatabase.parse('{'), throwsFormatException);
      expect(() => DeviceDatabase.parse('[]'), throwsFormatException);
      expect(() => DeviceDatabase.fromJson({'schema': 1}),
          throwsFormatException);
    });

    test('rejects a schema newer than the app understands', () {
      expect(
        () => DeviceDatabase.fromJson(
            {'schema': 999, 'version': 'x', 'brands': <Object?>[]}),
        throwsFormatException,
      );
    });

    test('rejects a series with a missing required field', () {
      final bad = doc([
        brand('b', [
          {'id': 's', 'name': 'S', 'hz': 60, 'ram': 4, 'tier': 3},
        ]),
      ]);
      expect(() => DeviceDatabase.fromJson(bad), throwsFormatException);
    });

    test('rejects an unknown platform', () {
      final bad = doc([brand('b', [series('s')], platform: 'symbian')]);
      expect(() => DeviceDatabase.fromJson(bad), throwsFormatException);
    });

    test('validate() flags out-of-range values and duplicates', () {
      final shaky = DeviceDatabase.fromJson(doc([
        brand('b', [
          series('s', inches: 20),
          series('s'),
          series('t', models: [
            {'name': 'One', 'codes': ['AB-1']},
            {'name': 'Two', 'codes': ['ab-1'], 'tier': 9},
          ]),
        ]),
        brand('b', [series('x')]),
      ]));
      final issues = shaky.validate().join('\n');
      expect(issues, contains('screen'));
      expect(issues, contains('duplicate series id'));
      expect(issues, contains('duplicate brand id'));
      expect(issues, contains('tier'));
      expect(issues, contains('code'));
    });
  });
}
