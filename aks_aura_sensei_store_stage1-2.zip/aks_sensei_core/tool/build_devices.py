#!/usr/bin/env python3
"""Builds assets/devices.json from the tables below.

Edit the tables (or the JSON directly), run `python3 tool/build_devices.py`,
then `dart test`. Series rows hold TYPICAL values for the line-up; model rows
override only what differs. Everything here is a SEED: verify specs against a
trusted source (manufacturer pages, GSMArena) before shipping, and mark rows
you have not checked with unverified=True.

Field legend:  in = screen inches, hz = max refresh rate, ram = marketed GB,
tier = 1..5 chipset class (see README), touch = touch sampling Hz (omit when
unknown; the engine then estimates it and tells the user).
"""
import json
import os

VERSION = "2026.10.20-seed"

TIER_LEGEND = {
    "5": "Snapdragon 8 Gen 1+, Dimensity 9000+, Exynos 2200+, Tensor G3+, Apple A12+",
    "4": "Snapdragon 7+ Gen 2 / 7 Gen 3 / 8s Gen 3 / 865-888, Dimensity 8xxx, Tensor G1-G2, Apple A11",
    "3": "Snapdragon 6 Gen / 7 Gen 1 / 695 / 778G / 720-732G, Dimensity 6xxx-7xxx, Helio G96-G99, Exynos 1280-1480, Apple A10",
    "2": "Snapdragon 4 Gen / 680 / 662, Helio G80-G91, Dimensity 700, Unisoc T7xx, Apple A9",
    "1": "Helio A / G35-G37, Snapdragon 4xx, Unisoc SC/T6xx, older chips",
}


def M(name, codes=None, inch=None, hz=None, ram=None, tier=None, touch=None, unverified=False):
    d = {"name": name}
    if codes:
        d["codes"] = codes
    for key, val in (("in", inch), ("hz", hz), ("ram", ram), ("tier", tier), ("touch", touch)):
        if val is not None:
            d[key] = val
    if unverified:
        d["unverified"] = True
    return d


def S(sid, name, inch, hz, ram, tier, models=None, touch=None):
    d = {"id": sid, "name": name, "in": inch, "hz": hz, "ram": ram, "tier": tier}
    if touch is not None:
        d["touch"] = touch
    if models:
        d["models"] = models
    return d


def B(bid, name, series, platform="android", aliases=None):
    d = {"id": bid, "name": name, "platform": platform}
    if aliases:
        d["aliases"] = aliases
    d["series"] = series
    return d


def IP(name, codes, inch, ram, hz=None, tier=None, unverified=False):
    return M(name, codes=codes, inch=inch, ram=ram, hz=hz, tier=tier, unverified=unverified)


BRANDS = [
    B("samsung", "Samsung", [
        S("galaxy-s", "Galaxy S", 6.4, 120, 8, 5, [
            M("Galaxy S25 Ultra", ["SM-S938B"], inch=6.9, ram=12),
            M("Galaxy S25", ["SM-S931B"], inch=6.2, ram=12),
            M("Galaxy S24 Ultra", ["SM-S928B", "SM-S928U"], inch=6.8, ram=12),
            M("Galaxy S24+", ["SM-S926B"], inch=6.7, ram=12),
            M("Galaxy S24", ["SM-S921B"], inch=6.2, ram=8),
            M("Galaxy S23 Ultra", ["SM-S918B"], inch=6.8, ram=12),
            M("Galaxy S23", ["SM-S911B"], inch=6.1, ram=8),
        ], touch=240),
        S("galaxy-z-fold", "Galaxy Z Fold", 7.6, 120, 12, 5, [
            M("Galaxy Z Fold6", ["SM-F956B"]),
            M("Galaxy Z Fold5", ["SM-F946B"]),
        ]),
        S("galaxy-z-flip", "Galaxy Z Flip", 6.7, 120, 8, 5, [
            M("Galaxy Z Flip6", ["SM-F741B"]),
        ]),
        S("galaxy-a", "Galaxy A", 6.5, 90, 6, 3, [
            M("Galaxy A55 5G", ["SM-A556B"], inch=6.6, hz=120, ram=8),
            M("Galaxy A54 5G", ["SM-A546B"], inch=6.4, hz=120, ram=8),
            M("Galaxy A15", ["SM-A155F"], ram=4),
            M("Galaxy A05", ["SM-A055F"], inch=6.7, hz=60, ram=4, tier=2),
        ]),
        S("galaxy-m", "Galaxy M", 6.6, 90, 6, 3, [
            M("Galaxy M34 5G", ["SM-M346B"], inch=6.5, hz=120),
        ]),
        S("galaxy-f", "Galaxy F", 6.6, 90, 6, 3, [
            M("Galaxy F14 5G", inch=6.6, ram=4, tier=2, unverified=True),
        ]),
        S("galaxy-xcover", "Galaxy XCover", 6.6, 60, 4, 2, [
            M("Galaxy XCover7", ["SM-G556B"], ram=6),
        ]),
    ]),
    B("xiaomi", "Xiaomi", [
        S("xiaomi-numbered", "Xiaomi (numbered)", 6.4, 120, 12, 5, [
            M("Xiaomi 14 Ultra", inch=6.73, ram=16),
            M("Xiaomi 14", inch=6.36),
            M("Xiaomi 13", inch=6.36, ram=8),
        ]),
        S("xiaomi-t", "Xiaomi T", 6.67, 144, 12, 4, [
            M("Xiaomi 14T Pro", tier=5),
            M("Xiaomi 14T"),
        ]),
        S("xiaomi-civi", "Xiaomi Civi", 6.55, 120, 12, 4),
        S("xiaomi-mix", "Xiaomi MIX", 6.5, 120, 12, 5),
    ]),
    B("redmi", "Redmi", [
        S("redmi-note", "Redmi Note", 6.67, 120, 8, 3, [
            M("Redmi Note 14 Pro 5G"),
            M("Redmi Note 13 Pro"),
            M("Redmi Note 13", ram=6),
            M("Redmi Note 12", ram=6),
            M("Redmi Note 10 Pro", ram=6),
        ]),
        S("redmi-numbered", "Redmi (numbered)", 6.6, 90, 4, 2, [
            M("Redmi 13", inch=6.79, hz=120, ram=6),
            M("Redmi 13C", inch=6.74),
            M("Redmi 12", inch=6.79),
            M("Redmi 10"),
            M("Redmi 9", ["M2004J19G", "M2004J19C"], inch=6.53, hz=60),
        ], ),
        S("redmi-a", "Redmi A", 6.7, 60, 3, 1, [
            M("Redmi A3", inch=6.71, hz=90),
            M("Redmi A2", inch=6.52, ram=2),
        ]),
        S("redmi-k", "Redmi K", 6.67, 120, 12, 5, [
            M("Redmi K70"),
            M("Redmi K60", ram=8),
        ]),
        S("redmi-turbo", "Redmi Turbo", 6.67, 120, 12, 4, [
            M("Redmi Turbo 3"),
        ]),
    ], aliases=["xiaomi"]),
    B("poco", "POCO", [
        S("poco-f", "POCO F", 6.67, 120, 8, 4, [
            M("POCO F6 Pro", ram=12, tier=5),
            M("POCO F6"),
            M("POCO F5"),
        ]),
        S("poco-x", "POCO X", 6.67, 120, 8, 3, [
            M("POCO X6 Pro", tier=4),
            M("POCO X6"),
            M("POCO X5 Pro", ram=6),
            M("POCO X3 Pro", ram=6, tier=4),
        ]),
        S("poco-m", "POCO M", 6.7, 90, 4, 2, [
            M("POCO M6 Pro", inch=6.79, ram=8, tier=3),
            M("POCO M6", inch=6.79, ram=6),
            M("POCO M5", inch=6.58, tier=3),
        ]),
        S("poco-c", "POCO C", 6.71, 90, 4, 1, [
            M("POCO C65", inch=6.74, ram=6, tier=2),
            M("POCO C55", hz=60, tier=2),
            M("POCO C3", inch=6.53, hz=60, ram=3, tier=1),
        ]),
    ], aliases=["xiaomi"]),
    B("google-pixel", "Google Pixel", [
        S("pixel", "Pixel", 6.3, 120, 12, 4, [
            M("Pixel 9", ["Pixel 9"]),
            M("Pixel 8", ["Pixel 8"], inch=6.2, ram=8),
            M("Pixel 7", ["Pixel 7"], hz=90, ram=8),
        ]),
        S("pixel-pro", "Pixel Pro", 6.8, 120, 16, 5, [
            M("Pixel 9 Pro XL", ["Pixel 9 Pro XL"]),
            M("Pixel 9 Pro", ["Pixel 9 Pro"], inch=6.3),
            M("Pixel 8 Pro", ["Pixel 8 Pro"], inch=6.7, ram=12, tier=4),
            M("Pixel 7 Pro", ["Pixel 7 Pro"], inch=6.7, ram=12, tier=4),
        ]),
        S("pixel-a", "Pixel a", 6.1, 90, 8, 4, [
            M("Pixel 8a", ["Pixel 8a"], hz=120),
            M("Pixel 7a", ["Pixel 7a"]),
            M("Pixel 6a", ["Pixel 6a"], hz=60, ram=6),
        ]),
        S("pixel-fold", "Pixel Fold", 7.6, 120, 12, 5, [
            M("Pixel 9 Pro Fold", ["Pixel 9 Pro Fold"], inch=8.0, ram=16),
            M("Pixel Fold", ["Pixel Fold"], tier=4),
        ]),
    ], aliases=["google"]),
    B("oneplus", "OnePlus", [
        S("oneplus-flagship", "OnePlus (flagship)", 6.8, 120, 12, 5, [
            M("OnePlus 13", inch=6.82),
            M("OnePlus 12", ["CPH2581"], inch=6.82),
            M("OnePlus 11", inch=6.7, ram=8),
        ]),
        S("oneplus-r", "OnePlus R", 6.78, 120, 12, 5, [
            M("OnePlus 13R"),
            M("OnePlus 12R", ram=8),
            M("OnePlus 10R", inch=6.7, ram=8, tier=4),
        ]),
        S("oneplus-nord", "OnePlus Nord", 6.7, 120, 8, 4, [
            M("OnePlus Nord 4", inch=6.74),
            M("OnePlus Nord 3", inch=6.74, tier=5),
            M("OnePlus Nord CE4", tier=3),
            M("OnePlus Nord CE3 Lite", inch=6.72, tier=3),
        ]),
        S("oneplus-open", "OnePlus Open", 7.82, 120, 16, 5, [
            M("OnePlus Open"),
        ]),
    ]),
    B("motorola", "Motorola", [
        S("moto-edge", "Edge", 6.6, 144, 8, 4, [
            M("Edge 50 Pro", inch=6.7, ram=12),
            M("Edge 40", inch=6.55),
            M("Edge 30 Ultra", inch=6.67, ram=12, tier=5),
        ]),
        S("moto-g", "Moto G", 6.5, 90, 4, 2, [
            M("Moto G84 5G", inch=6.55, hz=120, ram=8, tier=3),
            M("Moto G54 5G", hz=120, ram=8, tier=3),
            M("Moto G31", inch=6.4, hz=60),
        ]),
        S("moto-e", "Moto E", 6.5, 60, 3, 1, [
            M("Moto E13", ram=2),
            M("Moto E40", hz=90, ram=4, tier=2),
        ]),
        S("moto-razr", "Razr", 6.9, 165, 8, 4, [
            M("Razr 40 Ultra", tier=5),
            M("Razr 50 Ultra", ram=12),
            M("Razr 50", hz=120, tier=3),
        ]),
    ], aliases=["moto"]),
    B("nothing", "Nothing", [
        S("nothing-phone", "Nothing Phone", 6.7, 120, 8, 4, [
            M("Nothing Phone (2)", tier=5),
            M("Nothing Phone (2a)", tier=3),
            M("Nothing Phone (1)", inch=6.55, tier=3),
        ]),
    ]),
    B("cmf", "CMF", [
        S("cmf-phone", "CMF Phone", 6.67, 120, 8, 3, [
            M("CMF Phone 1"),
        ]),
    ], aliases=["nothing"]),
    B("oppo", "OPPO", [
        S("oppo-find-x", "Find X", 6.8, 120, 12, 5, [
            M("Find X7 Ultra", inch=6.82),
            M("Find X6 Pro", inch=6.82),
        ]),
        S("oppo-find-n", "Find N", 7.1, 120, 12, 5, [
            M("Find N3", inch=7.82, ram=16),
            M("Find N2"),
        ]),
        S("oppo-reno", "Reno", 6.7, 120, 8, 3, [
            M("Reno 12", ram=12),
            M("Reno 11"),
        ]),
        S("oppo-a", "OPPO A", 6.7, 90, 4, 2, [
            M("OPPO A78", inch=6.43, ram=8),
            M("OPPO A38", inch=6.56),
        ]),
        S("oppo-k", "OPPO K", 6.7, 120, 8, 3),
    ]),
    B("vivo", "vivo", [
        S("vivo-x", "vivo X", 6.78, 120, 12, 5, [
            M("vivo X100 Pro", ram=16),
            M("vivo X90 Pro"),
        ]),
        S("vivo-v", "vivo V", 6.78, 120, 8, 3, [
            M("vivo V30", tier=4),
            M("vivo V29"),
            M("vivo V27"),
        ]),
        S("vivo-y", "vivo Y", 6.6, 90, 6, 2, [
            M("vivo Y28", inch=6.56),
            M("vivo Y200", inch=6.67, hz=120, ram=8),
        ]),
        S("vivo-t", "vivo T", 6.67, 120, 8, 3, [
            M("vivo T3 5G"),
        ]),
        S("vivo-s", "vivo S", 6.78, 120, 12, 3),
    ]),
    B("iqoo", "iQOO", [
        S("iqoo-numbered", "iQOO (numbered)", 6.78, 144, 12, 5, [
            M("iQOO 13", inch=6.82),
            M("iQOO 12"),
            M("iQOO 11"),
        ]),
        S("iqoo-neo", "iQOO Neo", 6.78, 144, 8, 5, [
            M("iQOO Neo 9 Pro", ram=12),
            M("iQOO Neo 7 Pro", hz=120),
        ]),
        S("iqoo-z", "iQOO Z", 6.67, 120, 8, 3, [
            M("iQOO Z9 5G"),
        ]),
    ]),
    B("realme", "realme", [
        S("realme-gt", "realme GT", 6.78, 144, 12, 5, [
            M("realme GT 6", hz=120, tier=4),
            M("realme GT 5 Pro"),
        ]),
        S("realme-number", "realme (numbered)", 6.7, 120, 8, 3, [
            M("realme 12 Pro+ 5G"),
            M("realme 11 Pro"),
            M("realme 9 Pro+", inch=6.43, hz=90),
        ]),
        S("realme-p", "realme P", 6.67, 120, 8, 3, [
            M("realme P1 5G"),
            M("realme P1 Pro 5G", inch=6.7),
        ]),
        S("realme-narzo", "realme Narzo", 6.6, 90, 6, 2, [
            M("realme Narzo 70 Pro 5G", inch=6.67, hz=120, ram=8, tier=3),
            M("realme Narzo 50A", inch=6.5, hz=60, ram=4),
        ]),
        S("realme-c", "realme C", 6.74, 90, 4, 1, [
            M("realme C55", inch=6.72, ram=6, tier=2),
            M("realme C53", ram=6),
            M("realme C35", inch=6.6, hz=60),
        ]),
    ]),
    B("tecno", "TECNO", [
        S("tecno-phantom", "Phantom", 6.9, 120, 12, 4, [
            M("Phantom X2 Pro", inch=6.8, tier=5),
        ]),
        S("tecno-camon", "Camon", 6.7, 120, 8, 3, [
            M("Camon 30 Pro 5G", inch=6.78, hz=144, ram=12, tier=4),
            M("Camon 20 Pro", inch=6.67),
        ]),
        S("tecno-spark", "Spark", 6.6, 90, 4, 2, [
            M("Spark 20 Pro", inch=6.78, hz=120, ram=8, tier=3),
            M("Spark 10", ram=4, tier=1),
        ]),
        S("tecno-pova", "Pova", 6.78, 120, 8, 3, [
            M("Pova 6 Pro", ram=12),
            M("Pova 5"),
        ]),
        S("tecno-pop", "POP", 6.56, 90, 3, 1, [
            M("POP 8", inch=6.6, ram=4),
        ]),
    ]),
    B("infinix", "Infinix", [
        S("infinix-zero", "Zero", 6.7, 120, 8, 3, [
            M("Zero 30 5G", inch=6.78, hz=144, ram=12, tier=4),
            M("Zero 20", hz=60),
        ]),
        S("infinix-note", "Note", 6.78, 120, 8, 3, [
            M("Note 40 Pro"),
        ]),
        S("infinix-hot", "Hot", 6.78, 90, 4, 2, [
            M("Hot 40 Pro", hz=120, ram=8, tier=3),
            M("Hot 30", ram=8),
        ]),
        S("infinix-smart", "Smart", 6.6, 60, 3, 1, [
            M("Smart 8", hz=90, ram=4),
        ]),
        S("infinix-gt", "GT", 6.78, 120, 8, 4, [
            M("GT 20 Pro", hz=144, ram=12),
        ]),
    ]),
    B("itel", "itel", [
        S("itel-a", "itel A", 6.6, 60, 3, 1, [
            M("itel A70", hz=90, ram=4),
        ]),
        S("itel-p", "itel P", 6.6, 90, 6, 2, [
            M("itel P55"),
            M("itel P40", ram=4, tier=1),
        ]),
        S("itel-s", "itel S", 6.6, 90, 8, 2),
    ]),
    B("asus", "ASUS", [
        S("asus-zenfone", "Zenfone", 5.9, 120, 8, 5, [
            M("Zenfone 11 Ultra", inch=6.78, hz=144, ram=12),
            M("Zenfone 10"),
        ]),
        S("asus-rog-phone", "ROG Phone", 6.78, 165, 16, 5, [
            M("ROG Phone 8 Pro"),
            M("ROG Phone 8", ram=12),
            M("ROG Phone 7 Ultimate"),
        ], touch=720),
    ]),
    B("sony", "Sony Xperia", [
        S("xperia-1", "Xperia 1", 6.5, 120, 12, 5, [
            M("Xperia 1 V"),
        ]),
        S("xperia-5", "Xperia 5", 6.1, 120, 8, 5, [
            M("Xperia 5 V"),
        ]),
        S("xperia-10", "Xperia 10", 6.0, 60, 6, 3, [
            M("Xperia 10 V", inch=6.1),
        ]),
    ], aliases=["sony"]),
    B("honor", "HONOR", [
        S("honor-magic", "Magic", 6.8, 120, 12, 5, [
            M("Magic6 Pro"),
        ]),
        S("honor-magic-v", "Magic V", 7.9, 120, 12, 5, [
            M("Magic V2", inch=7.92, ram=16),
        ]),
        S("honor-number", "HONOR (numbered)", 6.7, 120, 8, 3, [
            M("HONOR 200", ram=12, tier=4),
            M("HONOR 90"),
        ]),
        S("honor-x", "HONOR X", 6.78, 120, 6, 2, [
            M("HONOR X9b", ram=8, tier=3),
            M("HONOR X8b", inch=6.7, hz=90, ram=8),
        ]),
        S("honor-play", "HONOR Play", 6.8, 60, 4, 1),
    ]),
    B("huawei", "Huawei", [
        S("huawei-mate", "Mate", 6.8, 120, 12, 4, [
            M("Mate 60 Pro", inch=6.82),
            M("Mate 50 Pro", inch=6.74, ram=8, tier=5),
        ]),
        S("huawei-mate-x", "Mate X", 7.85, 120, 12, 4, [
            M("Mate X5"),
        ]),
        S("huawei-pura", "Pura / P", 6.8, 120, 12, 4, [
            M("Pura 70 Pro"),
            M("P60 Pro", inch=6.67, ram=8, tier=5),
        ]),
        S("huawei-nova", "nova", 6.7, 120, 8, 3),
        S("huawei-enjoy", "Enjoy", 6.7, 60, 4, 1),
    ]),
    B("nokia-hmd", "Nokia / HMD", [
        S("nokia", "Nokia", 6.5, 60, 4, 1, [
            M("Nokia G42 5G", inch=6.56, hz=90, ram=6, tier=2),
            M("Nokia G21", hz=90, tier=1),
        ]),
        S("hmd", "HMD", 6.56, 90, 6, 2, [
            M("HMD Skyline", inch=6.55, hz=144, ram=12, tier=3),
            M("HMD Fusion", ram=8),
        ]),
    ], aliases=["nokia", "hmd"]),
    B("lenovo-legion", "Lenovo Legion", [
        S("legion-phone", "Legion Phone", 6.92, 144, 12, 5, [
            M("Legion Phone Duel 2", ram=16, touch=720),
            M("Legion Y90", ram=18),
        ]),
        S("legion-y", "Legion Y", 6.67, 144, 8, 5, [
            M("Legion Y70"),
        ]),
    ], aliases=["lenovo", "legion"]),
    B("zte-nubia-redmagic", "ZTE / nubia / RedMagic", [
        S("redmagic", "RedMagic", 6.8, 120, 12, 5, [
            M("RedMagic 9 Pro", ram=16),
            M("RedMagic 8 Pro"),
        ], touch=960),
        S("nubia-z", "nubia Z", 6.8, 120, 12, 5, [
            M("nubia Z60 Ultra"),
        ]),
        S("nubia-neo", "nubia Neo", 6.6, 120, 8, 3, [
            M("nubia Neo 2", inch=6.72),
        ]),
        S("zte-blade", "ZTE Blade", 6.6, 90, 4, 2, [
            M("ZTE Blade A72", inch=6.74, ram=3, tier=1),
        ]),
        S("zte-axon", "ZTE Axon", 6.8, 120, 12, 5, [
            M("ZTE Axon 40 Ultra"),
        ]),
    ], aliases=["zte", "nubia", "redmagic"]),
    B("tcl", "TCL", [
        S("tcl-numbered", "TCL (numbered)", 6.6, 90, 6, 2),
        S("tcl-nxtpaper", "TCL NXTPAPER", 6.78, 60, 8, 2),
    ]),
    B("alcatel", "Alcatel", [
        S("alcatel-1", "Alcatel 1", 6.0, 60, 2, 1),
        S("alcatel-3", "Alcatel 3", 6.5, 60, 4, 1),
        S("alcatel-v", "Alcatel V", 6.6, 90, 4, 2),
    ]),
    B("lava", "Lava", [
        S("lava-blaze", "Blaze", 6.7, 90, 4, 2),
        S("lava-agni", "Agni", 6.78, 120, 8, 3, [
            M("Lava Agni 2 5G"),
        ]),
        S("lava-yuva", "Yuva", 6.5, 90, 4, 1),
        S("lava-storm", "Storm", 6.78, 120, 8, 3),
    ]),
    B("micromax", "Micromax", [
        S("micromax-in", "IN series", 6.5, 60, 4, 2, [
            M("Micromax IN Note 1", inch=6.67),
        ]),
        S("micromax-canvas", "Canvas", 5.5, 60, 2, 1),
    ]),
    B("sharp", "Sharp", [
        S("aquos-r", "AQUOS R", 6.6, 240, 12, 5, [
            M("AQUOS R8 pro"),
        ]),
        S("aquos-sense", "AQUOS sense", 6.1, 60, 6, 3, [
            M("AQUOS sense8"),
        ]),
        S("aquos-wish", "AQUOS wish", 5.7, 60, 4, 2),
        S("aquos-zero", "AQUOS zero", 6.4, 120, 8, 3),
    ]),
    B("kyocera", "Kyocera", [
        S("kyocera-torque", "Torque", 5.5, 60, 4, 2),
        S("kyocera-duraforce", "DuraForce", 5.0, 60, 3, 1),
    ]),
    B("fairphone", "Fairphone", [
        S("fairphone", "Fairphone", 6.4, 60, 6, 3, [
            M("Fairphone 5", inch=6.46, hz=90, ram=8),
            M("Fairphone 4", inch=6.3),
            M("Fairphone 3", inch=5.65, ram=4, tier=1),
        ]),
    ]),
    B("cat", "CAT", [
        S("cat-s", "CAT S", 6.6, 120, 6, 3, [
            M("CAT S75"),
        ]),
    ]),
    B("crosscall", "Crosscall", [
        S("crosscall-core", "Core", 6.1, 60, 6, 2),
    ]),
    B("ulefone", "Ulefone", [
        S("ulefone-armor", "Armor", 6.78, 120, 12, 3, [
            M("Ulefone Armor 24"),
        ]),
    ]),
    B("blackview", "Blackview", [
        S("blackview-bv", "BV series", 6.67, 120, 12, 3, [
            M("Blackview BV9300", inch=6.7),
        ]),
    ]),
    B("doogee", "DOOGEE", [
        S("doogee-s", "S series", 6.58, 120, 8, 3, [
            M("DOOGEE S100 Pro", ram=12),
        ]),
    ]),
    B("oukitel", "OUKITEL", [
        S("oukitel-wp", "WP series", 6.78, 90, 8, 2),
    ]),
    B("umidigi", "UMIDIGI", [
        S("umidigi-bison", "Bison", 6.6, 90, 8, 2),
    ]),
    B("blu", "BLU", [
        S("blu-g", "BLU G", 6.5, 60, 4, 1),
        S("blu-view", "BLU View", 6.5, 60, 3, 1),
        S("blu-bold", "BLU Bold", 6.8, 90, 6, 2),
    ]),
    B("meizu", "Meizu", [
        S("meizu-numbered", "Meizu (numbered)", 6.7, 120, 12, 5, [
            M("Meizu 21", inch=6.55),
        ]),
        S("meizu-note", "Meizu Note", 6.78, 90, 8, 3),
    ]),
    B("lg", "LG", [
        S("lg-v", "LG V", 6.4, 60, 6, 4, [
            M("LG V60 ThinQ", inch=6.8, ram=8),
            M("LG V50 ThinQ"),
        ]),
        S("lg-g", "LG G", 6.1, 60, 6, 4, [
            M("LG G8 ThinQ"),
        ]),
        S("lg-wing-velvet", "LG Wing / Velvet", 6.8, 60, 8, 3, [
            M("LG Wing", ram=8),
            M("LG Velvet", ram=6),
        ]),
        S("lg-k-q", "LG K / Q", 6.2, 60, 3, 1, [
            M("LG K51S", inch=6.55),
        ]),
    ]),
    B("htc", "HTC", [
        S("htc-u", "HTC U", 6.0, 60, 6, 3, [
            M("HTC U23 Pro", inch=6.7, hz=90, ram=8),
            M("HTC U12+", tier=4),
        ]),
        S("htc-desire", "HTC Desire", 6.5, 60, 4, 1, [
            M("HTC Desire 22 Pro", inch=6.6, hz=120, ram=8, tier=3, unverified=True),
        ]),
        S("htc-wildfire", "HTC Wildfire", 6.53, 60, 4, 1),
    ]),
    B("blackberry", "BlackBerry", [
        S("blackberry-key", "KEY series", 4.5, 60, 4, 2, [
            M("BlackBerry KEY2", ram=6),
        ]),
        S("blackberry-priv", "Priv / Passport", 5.4, 60, 3, 1),
    ]),
    B("wiko", "Wiko", [
        S("wiko-view", "View", 6.5, 60, 3, 1),
        S("wiko-power", "Power", 6.6, 60, 4, 1),
        S("wiko-t", "T series", 6.5, 60, 4, 1),
    ]),
    B("walton", "Walton", [
        S("walton-primo", "Primo", 6.5, 60, 4, 1),
    ]),
    B("apple", "Apple", [
        S("iphone-classic", "iPhone (2007-2011)", 3.5, 60, 0.5, 1, [
            IP("iPhone", ["iPhone1,1"], 3.5, 0.125),
            IP("iPhone 3G", ["iPhone1,2"], 3.5, 0.125),
            IP("iPhone 3GS", ["iPhone2,1"], 3.5, 0.25),
            IP("iPhone 4", ["iPhone3,1", "iPhone3,2", "iPhone3,3"], 3.5, 0.5),
            IP("iPhone 4S", ["iPhone4,1"], 3.5, 0.5),
        ]),
        S("iphone-5", "iPhone 5 / SE (1st gen)", 4.0, 60, 1, 1, [
            IP("iPhone 5", ["iPhone5,1", "iPhone5,2"], 4.0, 1),
            IP("iPhone 5C", ["iPhone5,3", "iPhone5,4"], 4.0, 1),
            IP("iPhone 5S", ["iPhone6,1", "iPhone6,2"], 4.0, 1),
            IP("iPhone SE (1st generation)", ["iPhone8,4"], 4.0, 2, tier=2),
        ]),
        S("iphone-6", "iPhone 6 / 6S", 4.7, 60, 1, 1, [
            IP("iPhone 6", ["iPhone7,2"], 4.7, 1),
            IP("iPhone 6 Plus", ["iPhone7,1"], 5.5, 1),
            IP("iPhone 6S", ["iPhone8,1"], 4.7, 2, tier=2),
            IP("iPhone 6S Plus", ["iPhone8,2"], 5.5, 2, tier=2),
        ]),
        S("iphone-7", "iPhone 7", 4.7, 60, 2, 3, [
            IP("iPhone 7", ["iPhone9,1", "iPhone9,3"], 4.7, 2),
            IP("iPhone 7 Plus", ["iPhone9,2", "iPhone9,4"], 5.5, 3),
        ]),
        S("iphone-8-x", "iPhone 8 / X", 4.7, 60, 3, 4, [
            IP("iPhone 8", ["iPhone10,1", "iPhone10,4"], 4.7, 2),
            IP("iPhone 8 Plus", ["iPhone10,2", "iPhone10,5"], 5.5, 3),
            IP("iPhone X", ["iPhone10,3", "iPhone10,6"], 5.8, 3),
        ]),
        S("iphone-xr-xs", "iPhone XR / XS", 6.1, 60, 4, 5, [
            IP("iPhone XR", ["iPhone11,8"], 6.1, 3),
            IP("iPhone XS", ["iPhone11,2"], 5.8, 4),
            IP("iPhone XS Max", ["iPhone11,4", "iPhone11,6"], 6.5, 4),
        ]),
        S("iphone-11", "iPhone 11", 6.1, 60, 4, 5, [
            IP("iPhone 11", ["iPhone12,1"], 6.1, 4),
            IP("iPhone 11 Pro", ["iPhone12,3"], 5.8, 4),
            IP("iPhone 11 Pro Max", ["iPhone12,5"], 6.5, 4),
        ]),
        S("iphone-se", "iPhone SE (2nd / 3rd gen)", 4.7, 60, 3, 5, [
            IP("iPhone SE (2nd generation)", ["iPhone12,8"], 4.7, 3),
            IP("iPhone SE (3rd generation)", ["iPhone14,6"], 4.7, 4),
        ]),
        S("iphone-12", "iPhone 12", 6.1, 60, 4, 5, [
            IP("iPhone 12 mini", ["iPhone13,1"], 5.4, 4),
            IP("iPhone 12", ["iPhone13,2"], 6.1, 4),
            IP("iPhone 12 Pro", ["iPhone13,3"], 6.1, 6),
            IP("iPhone 12 Pro Max", ["iPhone13,4"], 6.7, 6),
        ]),
        S("iphone-13", "iPhone 13", 6.1, 60, 4, 5, [
            IP("iPhone 13 mini", ["iPhone14,4"], 5.4, 4),
            IP("iPhone 13", ["iPhone14,5"], 6.1, 4),
            IP("iPhone 13 Pro", ["iPhone14,2"], 6.1, 6, hz=120),
            IP("iPhone 13 Pro Max", ["iPhone14,3"], 6.7, 6, hz=120),
        ]),
        S("iphone-14", "iPhone 14", 6.1, 60, 6, 5, [
            IP("iPhone 14", ["iPhone14,7"], 6.1, 6),
            IP("iPhone 14 Plus", ["iPhone14,8"], 6.7, 6),
            IP("iPhone 14 Pro", ["iPhone15,2"], 6.1, 6, hz=120),
            IP("iPhone 14 Pro Max", ["iPhone15,3"], 6.7, 6, hz=120),
        ]),
        S("iphone-15", "iPhone 15", 6.1, 60, 6, 5, [
            IP("iPhone 15", ["iPhone15,4"], 6.1, 6),
            IP("iPhone 15 Plus", ["iPhone15,5"], 6.7, 6),
            IP("iPhone 15 Pro", ["iPhone16,1"], 6.1, 8, hz=120),
            IP("iPhone 15 Pro Max", ["iPhone16,2"], 6.7, 8, hz=120),
        ]),
        S("iphone-16", "iPhone 16", 6.1, 60, 8, 5, [
            IP("iPhone 16e", ["iPhone17,5"], 6.1, 8),
            IP("iPhone 16", ["iPhone17,3"], 6.1, 8),
            IP("iPhone 16 Plus", ["iPhone17,4"], 6.7, 8),
            IP("iPhone 16 Pro", ["iPhone17,1"], 6.3, 8, hz=120),
            IP("iPhone 16 Pro Max", ["iPhone17,2"], 6.9, 8, hz=120),
        ]),
        S("iphone-17", "iPhone 17", 6.3, 120, 8, 5, [
            IP("iPhone 17", ["iPhone18,3"], 6.3, 8),
            IP("iPhone Air", ["iPhone18,4"], 6.5, 12),
            IP("iPhone 17 Pro", ["iPhone18,1"], 6.3, 12),
            IP("iPhone 17 Pro Max", ["iPhone18,2"], 6.9, 12),
        ]),
        # iPhone 18 Pro: size, refresh rate and identifier confirmed from
        # Apple's tech specs / The Apple Wiki (Sep 2026); RAM is third-party.
        # Pro Max: announced alongside, specs not verified. The base iPhone 18
        # is intentionally absent until its specs are published.
        S("iphone-18", "iPhone 18", 6.3, 120, 12, 5, [
            IP("iPhone 18 Pro", ["iPhone19,2"], 6.3, 12),
            IP("iPhone 18 Pro Max", [], 6.9, 12, unverified=True),
        ]),
    ], platform="ios", aliases=["iphone"]),
]


def dump(path):
    out = ['{',
           ' "schema": 1,',
           f' "version": "{VERSION}",',
           ' "_note": "SEED DATA - verify specs before release. Series rows are typical values; models override.",',
           f' "tier_legend": {json.dumps(TIER_LEGEND, ensure_ascii=False)},',
           ' "brands": [']
    brand_chunks = []
    for b in BRANDS:
        head = {k: v for k, v in b.items() if k != "series"}
        lines = ['  ' + json.dumps(head, ensure_ascii=False)[:-1] + ', "series": [']
        series_chunks = []
        for s in b["series"]:
            models = s.get("models")
            srow = {k: v for k, v in s.items() if k != "models"}
            if not models:
                series_chunks.append('   ' + json.dumps(srow, ensure_ascii=False))
                continue
            ml = ',\n'.join('     ' + json.dumps(m, ensure_ascii=False) for m in models)
            series_chunks.append('   ' + json.dumps(srow, ensure_ascii=False)[:-1]
                                 + ', "models": [\n' + ml + '\n   ]}')
        lines.append(',\n'.join(series_chunks))
        lines.append('  ]}')
        brand_chunks.append('\n'.join(lines))
    out.append(',\n'.join(brand_chunks))
    out.append(' ]')
    out.append('}')
    text = '\n'.join(out) + '\n'
    json.loads(text)  # fail loudly if the output is not valid JSON
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)
    return text


if __name__ == '__main__':
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    target = os.path.join(root, 'assets', 'devices.json')
    dump(target)
    n_series = sum(len(b['series']) for b in BRANDS)
    n_models = sum(len(s.get('models', [])) for b in BRANDS for s in b['series'])
    print(f'wrote {target}: {len(BRANDS)} brands, {n_series} series, {n_models} models')
